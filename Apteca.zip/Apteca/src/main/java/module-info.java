module com.example.apteca {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.web;
    requires com.microsoft.sqlserver.jdbc;

    requires eu.hansolo.tilesfx;
    requires java.sql;
   // requires com.example.apteca;
    requires javafx.base;
    requires javafx.graphics;

    opens com.example.apteca to javafx.fxml;
    opens com.example.apteca.Controllers to javafx.fxml;
    opens com.example.apteca.Model to javafx.base;
    exports com.example.apteca;
}