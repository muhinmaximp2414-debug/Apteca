module com.example.apteca {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.web;
    requires com.microsoft.sqlserver.jdbc;

    requires eu.hansolo.tilesfx;
    requires java.sql;
   // requires com.example.apteca;
    requires javafx.base;
    requires javafx.graphics;
   // requires com.example.apteca;
    //requires com.example.apteca;
    // requires com.example.apteca;

    opens com.example.apteca to javafx.fxml;
    //opens com.example.apteca.controllers. to javafx.fxml;
    opens com.example.apteca.model to javafx.base;
    exports com.example.apteca;
    opens com.example.apteca.controllers.pageControllers to javafx.fxml;
    opens com.example.apteca.controllers.changeControllers to javafx.fxml;
}