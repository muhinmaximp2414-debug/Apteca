package com.example.apteca.helpers;

import javafx.collections.ObservableList;
import javafx.scene.control.TextField;

import java.util.function.BiPredicate;

public class SearchHelper <T> {
    private final TextField searchField;
    private final ObservableList<T> sourceList;
    private final ObservableList<T> filteredList;
    private final Runnable onSearchChanged;
    private final BiPredicate<T, String> matcher;

    public SearchHelper(
            TextField searchField,
            ObservableList<T> sourceList,
            ObservableList<T> filteredList,
            BiPredicate<T, String> matcher,
            Runnable onSearchChanged
    ) {
        this.searchField = searchField;
        this.sourceList = sourceList;
        this.filteredList = filteredList;
        this.matcher = matcher;
        this.onSearchChanged = onSearchChanged;
    }

    public void setup() {
        searchField.textProperty().addListener((obs, oldValue, newValue) -> {
            applySearch(newValue);
            onSearchChanged.run();
        });
    }

    public void applySearch() {
        applySearch(searchField == null ? "" : searchField.getText());
    }

    public void applySearch(String query) {
        String searchText = query == null ? "" : query.trim().toLowerCase();

        if (searchText.isEmpty()) {
            filteredList.setAll(sourceList);
            return;
        }

        filteredList.setAll(
                sourceList.stream()
                        .filter(item -> matcher.test(item, searchText))
                        .toList()
        );
    }

    public static boolean containsIgnoreCase(String value, String searchText) {
        return value != null && value.toLowerCase().contains(searchText);
    }
}
