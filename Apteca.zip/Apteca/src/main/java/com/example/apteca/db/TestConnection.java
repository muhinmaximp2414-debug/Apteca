package com.example.apteca.db;

import java.sql.Connection;
import java.sql.SQLException;

    public class TestConnection {
        public static void main(String[] args) {
            System.out.println("Проверка подключения к MSSQL (Windows Auth)...");

            try (Connection conn = DatabaseConnection.getConnection()) {
                if (conn != null && !conn.isClosed()) {
                    System.out.println("✅ УСПЕХ! Соединение установлено.");
                    System.out.println("Текущая база данных: " + conn.getCatalog());
                }
            } catch (SQLException e) {
                System.err.println("❌ ОШИБКА: Не удалось подключиться!");
                System.err.println("Причина: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }
