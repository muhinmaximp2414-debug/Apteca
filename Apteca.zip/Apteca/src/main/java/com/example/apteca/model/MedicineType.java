package com.example.apteca.model;

public enum MedicineType implements DbNamedEnum {
    TABLETS("Таблетки"),
    CAPSULES("Капсулы"),
    SYRUP("Сироп"),
    OINTMENT("Мазь"),
    DROPS("Капли"),
    SOLUTION("Раствор");

    private final String dbName;

    MedicineType(String dbName) {
        this.dbName = dbName;
    }

    @Override
    public String getDbName() {
        return dbName;
    }
    public static MedicineType fromDbName(String dbName) {
        for (MedicineType type : values()) {
            if (type.dbName.equals(dbName)) {
                return type;
            }
        }
        throw new IllegalArgumentException("Неизвестный тип лекарства: " + dbName);
    }

}
