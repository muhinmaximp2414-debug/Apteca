package com.example.apteca.controllers.pageControllers;

import com.example.apteca.model.Category;
import com.example.apteca.model.MedicineType;
import com.example.apteca.services.FilterService;
import com.example.apteca.services.SearchService;
import com.example.apteca.services.SortingService;
import com.example.apteca.model.Medicine;
import com.example.apteca.repository.MedicineRepository;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

public class MedicineController extends PageController<Medicine> {

    @FXML private Pagination pagination;
    @FXML private TextField searchField;
    @FXML private ComboBox<String> categoryFilter;
    @FXML private ComboBox<String> typeFilter;
    @FXML private CheckBox recipeFilter;

    @FXML private TableView<Medicine> medicineTable;

    @FXML private TableColumn<Medicine, String> medicineNameColumn;
    @FXML private TableColumn<Medicine, String> activeIngredientColumn;
    @FXML private TableColumn<Medicine, String> categoryColumn;
    @FXML private TableColumn<Medicine, String> medicineTypeColumn;
    @FXML private TableColumn<Medicine, BigDecimal> salePriceColumn;
    @FXML private TableColumn<Medicine, Boolean> recipeColumn;

    private final MedicineRepository medicineRepository = new MedicineRepository();

    @FXML
    public void initialize() {
        setupFilters();
        initializeBase();
    }

    @FXML
    public void onMedicineAddButtonClick(ActionEvent event) {
        handleAdd();
    }

    @FXML
    public void onMedicineEditButtonClick(ActionEvent event) {
        handleEdit();
    }

    @FXML
    public void onMedicineDeleteButtonClick(ActionEvent event) {
        handleDelete();
    }

    @FXML
    public void onExportCsvButtonClick(ActionEvent event) {
        exportCsv(
                "Сохранить лекарства в CSV",
                "medicines.csv",
                new String[]{
                        "Название",
                        "Действующее вещество",
                        "Категория",
                        "Тип",
                        "Цена продажи",
                        "Рецепт"
                },
                List.of(
                        Medicine::getMedicineName,
                        Medicine::getActiveIngredient,
                        Medicine::getCategoryName,
                        Medicine::getMedicineTypeName,
                        medicine -> String.valueOf(medicine.getSalePrice()),
                        medicine -> medicine.isRecipe() ? "Да" : "Нет"
                )
        );
    }

    @Override
    protected TableView<Medicine> getTable() {
        return medicineTable;
    }

    @Override
    protected Pagination getPagination() {
        return pagination;
    }

    @Override
    protected TextField getSearchField() {
        return searchField;
    }

    @Override
    protected List<Medicine> findAll() throws SQLException {
        return medicineRepository.findAll();
    }

    @Override
    protected void deleteItem(Medicine medicine) throws SQLException {
        medicineRepository.deleteFromDatabase(medicine);
    }

    @Override
    protected void setupColumns() {
        medicineNameColumn.setCellValueFactory(new PropertyValueFactory<>("MedicineName"));
        activeIngredientColumn.setCellValueFactory(new PropertyValueFactory<>("ActiveIngredient"));
        categoryColumn.setCellValueFactory(new PropertyValueFactory<>("CategoryName"));
        medicineTypeColumn.setCellValueFactory(new PropertyValueFactory<>("MedicineTypeName"));
        salePriceColumn.setCellValueFactory(new PropertyValueFactory<>("SalePrice"));
        recipeColumn.setCellValueFactory(new PropertyValueFactory<>("Recipe"));
    }

    @Override
    protected void setupSorting() {
        sortHelper = new SortingService<>(
                medicineTable,
                filteredList,
                originalList,
                () -> paginationHelper.loadPage(paginationHelper.getCurrentPageIndex())
        );

        sortHelper.addSortableColumn(medicineNameColumn, "Название");
        sortHelper.addSortableColumn(activeIngredientColumn, "Действующее вещество");
        sortHelper.addSortableColumn(categoryColumn, "Категория");
        sortHelper.addSortableColumn(medicineTypeColumn, "Тип");
        sortHelper.addSortableColumn(salePriceColumn, "Цена продажи");
        sortHelper.addSortableColumn(recipeColumn, "Рецепт");
    }

    @Override
    protected boolean matchesSearch(Medicine medicine, String searchText) {
        return SearchService.containsIgnoreCase(medicine.getMedicineName(), searchText) ||
                SearchService.containsIgnoreCase(medicine.getActiveIngredient(), searchText);
    }

    @Override
    protected String getDeleteConfirmationMessage(Medicine medicine) {
        return "Удалить лекарство \"" + medicine.getMedicineName() + "\"?";
    }

    @Override
    protected void openEditor(Medicine medicine) {
        openChangeEditor(
                "/com/example/apteca/views/change-view/medicine-change-view.fxml",
                "/com/example/apteca/styles/addStyle.css",
                "Добавить лекарство",
                "Изменить лекарство",
                medicine
        );
    }

    @FXML
    public void onResetFiltersButtonClick(ActionEvent actionEvent) {
        resetComboFilter(categoryFilter);
        resetComboFilter(typeFilter);
        resetCheckFilter(recipeFilter);

        applySearchAndFilters();
    }

    @Override
    protected boolean matchesFilters(Medicine medicine) {
        return matchesComboFilter(categoryFilter, medicine.getCategoryName()) &&
                matchesComboFilter(typeFilter, medicine.getMedicineTypeName()) &&
                (!recipeFilter.isSelected() || medicine.isRecipe());
    }

    private void setupFilters() {
        setupComboFilter(categoryFilter, enumDbNamesWithAll(Category.class));
        setupComboFilter(typeFilter, enumDbNamesWithAll(MedicineType.class));
        setupCheckFilter(recipeFilter);
    }
}
