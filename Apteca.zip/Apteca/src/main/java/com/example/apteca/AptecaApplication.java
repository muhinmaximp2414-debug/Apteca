package com.example.apteca;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class AptecaApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(AptecaApplication.class.getResource("/com/example/apteca/views/page-views/side-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 1024, 600);
        scene.getStylesheets().add(AptecaApplication.class.getResource("/com/example/apteca/styles/SideStyle.css").toExternalForm());
        stage.setTitle("Apteca!");
        stage.setMaximized(true);
        stage.setScene(scene);
        stage.show();
    }
}
