package com.example.apteca.Controllers;

import com.example.apteca.Model.Supplier;
import com.example.apteca.db.DatabaseConnection;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

public class SupplierAddController {
    public Button btnSave;
    public TextField fieldName;
    public TextField fieldAddress;
    public TextField fieldEmail;
    public TextField fieldPhone;

    private Supplier supplier;
    private ObservableList<Supplier> supplierList;


    public void initialize() {
        fieldPhone.setTextFormatter(new TextFormatter<String>(change -> {
            String oldText = change.getControlText();
            String newText = change.getControlNewText();

            String digits = newText.replaceAll("\\D", "");

            if (digits.length() > 8) {
                return null;
            }

            StringBuilder formatted = new StringBuilder();

            for (int i = 0; i < digits.length(); i++) {
                if (i == 2 || i == 5) {
                    formatted.append(" ");
                }

                formatted.append(digits.charAt(i));
            }

            change.setText(formatted.toString());
            change.setRange(0, oldText.length());
            change.setCaretPosition(formatted.length());
            change.setAnchor(formatted.length());

            return change;


        }));
    }

    public void setSupplier(Supplier supplier) {
        this.supplier = supplier;

        if (supplier != null) {
            fieldName.setText(supplier.getSupplierName());
            fieldAddress.setText(supplier.getSupplierAddress());
            fieldEmail.setText(supplier.getSupplierEmail());

            String phone = supplier.getSupplierPhone();

            if (phone != null) {
                phone = phone.replaceAll("\\D", "");

                if (phone.startsWith("373") && phone.length() > 8) {
                    phone = phone.substring(3);
                }
            }

            fieldPhone.setText(phone);
        }
    }

    public void onSaveButtonClick(ActionEvent actionEvent) {
        try {
            if (fieldName.getText().isEmpty() ||
                    fieldAddress.getText().isEmpty() ||
                    fieldEmail.getText().isEmpty() ||
                    fieldPhone.getText().isEmpty()) {

                showError("Все поля должны быть заполнены!");
                return;
            }


            if (supplier == null) {
                supplier = new Supplier();

                supplier.setSupplierName(fieldName.getText());
                supplier.setSupplierAddress(fieldAddress.getText());
                supplier.setSupplierEmail(fieldEmail.getText());
                supplier.setSupplierPhone("+373" + fieldPhone.getText().replaceAll(" ", ""));

                saveSupplierToDatabase(supplier);

            } else {
                supplier.setSupplierName(fieldName.getText());
                supplier.setSupplierAddress(fieldAddress.getText());
                supplier.setSupplierEmail(fieldEmail.getText());
                supplier.setSupplierPhone("+373" + fieldPhone.getText().replaceAll(" ", ""));

                editSupplierInDatabase(supplier);
            }

            close();

        } catch (SQLException e) {

            showError("Ошибка базы данных:\n" + e.getMessage());

        } catch (Exception e) {

            showError("Ошибка:\n" + e.getMessage());
        }

    }



    public void setAll(ObservableList<Supplier> supplierList) {
        this.supplierList = supplierList;
    }

    private void saveSupplierToDatabase(Supplier supplier)
            throws SQLException {

        String sql = "{call AddSupplier(?, ?, ?, ?)}";


        try (
                Connection conn = DatabaseConnection.getConnection();
                CallableStatement stmt = conn.prepareCall(sql)
        ) {

            stmt.setString(1, supplier.getSupplierName());
            stmt.setString(2, supplier.getSupplierPhone());
            stmt.setString(3, supplier.getSupplierEmail());
            stmt.setString(4, supplier.getSupplierAddress());

            stmt.executeUpdate();
        }
    }

    private void editSupplierInDatabase(Supplier supplier) throws SQLException{
            String sql = "{call EditSupplier(?, ?, ?, ?, ?)}";

            try (
                    Connection conn = DatabaseConnection.getConnection();
                    CallableStatement stmt = conn.prepareCall(sql)
            ) {
                stmt.setInt(1, supplier.getIdsupplier());
                stmt.setString(2, supplier.getSupplierName());
                stmt.setString(3, supplier.getSupplierPhone());
                stmt.setString(4, supplier.getSupplierEmail());
                stmt.setString(5, supplier.getSupplierAddress());

                stmt.executeUpdate();
            }
    }


    public void onCancelButtonClick(ActionEvent actionEvent) {
        close();
    }




    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Ошибка");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void close() {
        ((Stage) fieldName.getScene().getWindow()).close();
    }




}
