package com.example.apteca.repository;

import com.example.apteca.db.DatabaseConnection;
import com.example.apteca.model.Category;
import com.example.apteca.model.Medicine;
import com.example.apteca.model.MedicineType;
import com.example.apteca.model.Supplier;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MedicineRepository implements Repository<Medicine> {
    public List<Medicine> findAll() throws SQLException {
        String sql = """
                SELECT 
                    ID_Medicine,
                    Medicine_name,
                    Active_ingredient,
                    Category_name,
                    Medicine_type_name,         
                    Sale_price,
                    Recipe
                FROM Type_medicine_view
                """;

        List<Medicine> medicines = new ArrayList<>();

        try (
                Connection conn = DatabaseConnection.getConnection();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)
        ) {
            while (rs.next()) {
                medicines.add(new Medicine(
                        rs.getInt("ID_Medicine"),
                        rs.getString("Medicine_name"),
                        rs.getString("Active_ingredient"),
                        Category.fromDbName(rs.getString("Category_name")),
                        MedicineType.fromDbName(rs.getString("Medicine_type_name")),
                        rs.getDouble("Sale_price"),
                        rs.getBoolean("Recipe")
                ));
            }
        }

        return medicines;
    }

    public void addToDatabase(Medicine medicine) throws SQLException {
        String sql = "{call AddMedicine(?, ?, ?, ?, ?, ?)}";

        try (
                Connection conn = DatabaseConnection.getConnection();
                CallableStatement stmt = conn.prepareCall(sql)
        ) {
            stmt.setString(1, medicine.getMedicineName());
            stmt.setString(2, medicine.getActiveIngredient());
            stmt.setString(3, medicine.getCategoryName());
            stmt.setString(4, medicine.getMedicineTypeName());
            stmt.setDouble(5, medicine.getSalePrice());
            stmt.setBoolean(6, medicine.isRecipe());

            stmt.executeUpdate();
        }
    }

    public void updateInDatabase(Medicine medicine) throws SQLException {
        String sql = "{call EditMedicine(?, ?, ?, ?, ?, ?, ?)}";

        try (
                Connection conn = DatabaseConnection.getConnection();
                CallableStatement stmt = conn.prepareCall(sql)
        ) {
            stmt.setInt(1, medicine.getIdMedicine());
            stmt.setString(2, medicine.getMedicineName());
            stmt.setString(3, medicine.getActiveIngredient());
            stmt.setString(4, medicine.getCategoryName());
            stmt.setString(5, medicine.getMedicineTypeName());
            stmt.setDouble(6, medicine.getSalePrice());
            stmt.setBoolean(7, medicine.isRecipe());

            stmt.executeUpdate();
        }
    }

    public void deleteFromDatabase(Medicine medicine) throws SQLException {
        String sql = "{call DeleteMedicine(?)}";

        try (
                Connection conn = DatabaseConnection.getConnection();
                CallableStatement stmt = conn.prepareCall(sql)
        ) {
            stmt.setInt(1, medicine.getIdMedicine());

            stmt.executeUpdate();
        }
    }
}
