package com.example.apteca.model;

import java.time.LocalDateTime;

public class MedicineBatch {
    private int idBatch;
    private Medicine medicine;
    private Supplier supplier;
    private double price;
    private int quantity;
    private LocalDateTime expirationDate;
    private LocalDateTime deliveryDate;

    public MedicineBatch(int idBatch, Medicine medicine, Supplier supplier, double price, int quantity, LocalDateTime expiration_date, LocalDateTime expiration_date1) {
        this.idBatch = idBatch;
        this.medicine = medicine;
        this.supplier = supplier;
        this.price = price;
        this.quantity = quantity;
        expirationDate = expiration_date;
        this.deliveryDate = expiration_date1;
    }

    public int getIdBatch() {
        return idBatch;
    }

    public void setIdBatch(int idBatch) {
        this.idBatch = idBatch;
    }

    public Medicine getMedicine() {
        return medicine;
    }

    public void setMedicine(Medicine medicine) {
        this.medicine = medicine;
    }

    public String getMedicineName() {
        return medicine == null ? "" : medicine.getMedicineName();
    }

    public String getSupplierName() {
        return supplier == null ? "" : supplier.getSupplierName();
    }

    public Supplier getSupplier() {
        return supplier;
    }

    public void setSupplier(Supplier supplier) {
        this.supplier = supplier;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public LocalDateTime getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(LocalDateTime deliveryDate) {
        expirationDate = deliveryDate;
    }

    public LocalDateTime getDeliveryDate() {
        return deliveryDate;
    }

    public void setDeliveryDate(LocalDateTime deliveryDate) {
        deliveryDate = deliveryDate;
    }
}
