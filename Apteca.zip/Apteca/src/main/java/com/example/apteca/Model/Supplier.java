package com.example.apteca.Model;

public class Supplier {
    private int idsupplier;
    private String supplierName;
    private String supplierEmail;
    private String supplierPhone;
    private String supplierAddress;

    public Supplier() {
        this.idsupplier = 0;
        this.supplierName = "a";
        this.supplierAddress = "a";
        this.supplierEmail = "a";
        this.supplierPhone = "+37312345678";
    }

    public Supplier(int id_supplier, String supplier_name, String supplier_phone , String supplier_email, String supplier_address) {
        this.idsupplier = id_supplier;
        this.supplierName = supplier_name;
        this.supplierAddress = supplier_address;
        this.supplierEmail = supplier_email;
        this.supplierPhone = supplier_phone;
    }

    public int getIdsupplier() {
        return idsupplier;
    }

    public void setIdsupplier(int idsupplier) {
        this.idsupplier = idsupplier;
    }

    public String getSupplierName() {
        return supplierName;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    public String getSupplierAddress() {
        return supplierAddress;
    }

    public void setSupplierAddress(String supplierAddress) {
        this.supplierAddress = supplierAddress;
    }

    public String getSupplierEmail() {
        return supplierEmail;
    }

    public void setSupplierEmail(String supplierEmail) {
        this.supplierEmail = supplierEmail;
    }

    public String getSupplierPhone() {
        return supplierPhone;
    }

    public void setSupplierPhone(String supplierPhone) {
        this.supplierPhone = supplierPhone;
    }

    @Override
    public String toString() {
        return "Supplier{" +
                "id_supplier=" + idsupplier +
                ", supplier_name='" + supplierName + '\'' +
                ", supplier_address='" + supplierAddress + '\'' +
                ", supplier_email='" + supplierEmail + '\'' +
                ", supplier_phone='" + supplierPhone + '\'' +
                '}';
    }
}
