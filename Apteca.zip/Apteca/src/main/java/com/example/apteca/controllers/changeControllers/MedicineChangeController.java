package com.example.apteca.controllers.changeControllers;

import com.example.apteca.model.Medicine;
import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

import com.example.apteca.model.Category;
import com.example.apteca.model.Medicine;
import com.example.apteca.model.MedicineType;
import com.example.apteca.repository.MedicineRepository;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.util.StringConverter;

import java.sql.SQLException;

public class MedicineChangeController extends ChangeController<Medicine> {

    @FXML private Label changeMedicineTitle;

    @FXML private TextField fieldMedicineName;
    @FXML private TextField fieldActiveIngredient;
    @FXML private ComboBox<Category> fieldCategory;
    @FXML private ComboBox<MedicineType> fieldMedicineType;
    @FXML private TextField fieldSalePrice;
    @FXML private CheckBox fieldRecipe;

    @FXML private Label errMedicineName;
    @FXML private Label errActiveIngredient;
    @FXML private Label errCategory;
    @FXML private Label errMedicineType;
    @FXML private Label errSalePrice;

    @FXML private Button btnSave;

    private final MedicineRepository medicineRepository = new MedicineRepository();

    @FXML
    private void initialize() {
        setupCategoryComboBox();
        setupMedicineTypeComboBox();
    }

    private void setupCategoryComboBox() {
        fieldCategory.setItems(FXCollections.observableArrayList(Category.values()));

        fieldCategory.setConverter(new StringConverter<>() {
            @Override
            public String toString(Category category) {
                return category == null ? "" : category.getDbName();
            }

            @Override
            public Category fromString(String value) {
                return Category.fromDbName(value);
            }
        });
    }

    private void setupMedicineTypeComboBox() {
        fieldMedicineType.setItems(FXCollections.observableArrayList(MedicineType.values()));

        fieldMedicineType.setConverter(new StringConverter<>() {
            @Override
            public String toString(MedicineType medicineType) {
                return medicineType == null ? "" : medicineType.getDbName();
            }

            @Override
            public MedicineType fromString(String value) {
                return MedicineType.fromDbName(value);
            }
        });
    }

    @Override
    protected Button getSaveButton() {
        return btnSave;
    }

    @Override
    protected Label getTitleLabel() {
        return changeMedicineTitle;
    }

    @Override
    protected Node getAnyNode() {
        return btnSave;
    }

    @Override
    protected String getAddTitle() {
        return "Добавить лекарство";
    }

    @Override
    protected String getEditTitle() {
        return "Изменить лекарство";
    }

    @Override
    protected boolean validateForm() {
        boolean valid = true;

        hideErrors();

        if (fieldMedicineName.getText().trim().isEmpty()) {
            showError(errMedicineName);
            valid = false;
        }

        if (fieldActiveIngredient.getText().trim().isEmpty()) {
            showError(errActiveIngredient);
            valid = false;
        }

        if (fieldCategory.getValue() == null) {
            showError(errCategory);
            valid = false;
        }

        if (fieldMedicineType.getValue() == null) {
            showError(errMedicineType);
            valid = false;
        }

        try {
            double price = Double.parseDouble(fieldSalePrice.getText().trim());

            if (price < 0) {
                showError(errSalePrice);
                valid = false;
            }
        } catch (NumberFormatException e) {
            showError(errSalePrice);
            valid = false;
        }

        return valid;
    }

    private void hideErrors() {
        hideError(errMedicineName);
        hideError(errActiveIngredient);
        hideError(errCategory);
        hideError(errMedicineType);
        hideError(errSalePrice);
    }

    private void showError(Label label) {
        label.setVisible(true);
        label.setManaged(true);
    }

    private void hideError(Label label) {
        label.setVisible(false);
        label.setManaged(false);
    }

    @Override
    protected Medicine createEntity() {
        return new Medicine(
                0,
                "",
                "",
                null,
                null,
                0,
                false
        );
    }

    @Override
    protected void fillFieldsFromEntity() {
        fieldMedicineName.setText(entity.getMedicineName());
        fieldActiveIngredient.setText(entity.getActiveIngredient());
        fieldCategory.setValue(entity.getCategory());
        fieldMedicineType.setValue(entity.getMedicineType());
        fieldSalePrice.setText(String.valueOf(entity.getSalePrice()));
        fieldRecipe.setSelected(entity.isRecipe());
    }

    @Override
    protected void fillEntityFromFields(Medicine medicine) {
        medicine.setMedicineName(fieldMedicineName.getText().trim());
        medicine.setActiveIngredient(fieldActiveIngredient.getText().trim());
        medicine.setCategory(fieldCategory.getValue());
        medicine.setMedicineType(fieldMedicineType.getValue());
        medicine.setSalePrice(Double.parseDouble(fieldSalePrice.getText().trim()));
        medicine.setRecipe(fieldRecipe.isSelected());
    }

    @Override
    protected void addEntity(Medicine medicine) throws SQLException {
        medicineRepository.addToDatabase(medicine);
    }

    @Override
    protected void editEntity(Medicine medicine) throws SQLException {
        medicineRepository.updateInDatabase(medicine);
    }
}
