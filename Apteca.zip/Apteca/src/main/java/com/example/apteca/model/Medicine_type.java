package com.example.apteca.model;

public enum Medicine_type {
}
