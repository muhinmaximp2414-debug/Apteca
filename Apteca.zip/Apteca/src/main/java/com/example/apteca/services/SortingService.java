package com.example.apteca.services;

import javafx.collections.ObservableList;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

public class SortingService<T> {
    private final TableView<T> tableView;
    private final ObservableList<T> fullList;
    private final ObservableList<T> originalList;
    private final Runnable reloadPage;

    private TableColumn<T, ?> currentSortColumn;
    private int sortClickCount = 0;

    public SortingService(
            TableView<T> tableView,
            ObservableList<T> fullList,
            ObservableList<T> originalList,
            Runnable reloadPage
    ) {
        this.tableView = tableView;
        this.fullList = fullList;
        this.originalList = originalList;
        this.reloadPage = reloadPage;
    }

    public void addSortableColumn(TableColumn<T, ?> column, String title) {
        column.setSortable(false);

        Label label = new Label(title);
        label.setUserData(title);
        label.setMaxWidth(Double.MAX_VALUE);

        column.setText(null);
        column.setGraphic(label);

        label.setOnMouseClicked(event -> {
            if (currentSortColumn != column) {
                currentSortColumn = column;
                sortClickCount = 1;
            } else {
                sortClickCount++;
            }

            if (sortClickCount == 1) {
                sortByColumn(column, true);
                resetColumnTitles();
                label.setText(title + " ▲");
            } else if (sortClickCount == 2) {
                sortByColumn(column, false);
                resetColumnTitles();
                label.setText(title + " ▼");
            } else {
                fullList.setAll(originalList);
                currentSortColumn = null;
                sortClickCount = 0;
                resetColumnTitles();
            }

            reloadPage.run();
        });
    }

    private void sortByColumn(TableColumn<T, ?> column, boolean ascending) {
        fullList.sort((item1, item2) -> {
            int result = compareByColumn(column, item1, item2);
            return ascending ? result : -result;
        });
    }

    private int compareByColumn(TableColumn<T, ?> column, T item1, T item2) {
        Object value1 = column.getCellObservableValue(item1).getValue();
        Object value2 = column.getCellObservableValue(item2).getValue();

        if (value1 == null && value2 == null) return 0;
        if (value1 == null) return -1;
        if (value2 == null) return 1;

        return value1.toString().compareToIgnoreCase(value2.toString());
    }

    private void resetColumnTitles() {
        for (TableColumn<T, ?> column : tableView.getColumns()) {
            if (column.getGraphic() instanceof Label label) {
                label.setText(label.getUserData().toString());
            }
        }
    }

    public void applyCurrentSort() {
        if (currentSortColumn == null) {
            fullList.setAll(originalList);
            return;
        }

        if (sortClickCount == 1) {
            sortByColumn(currentSortColumn, true);
        } else if (sortClickCount == 2) {
            sortByColumn(currentSortColumn, false);
        }
    }
}
