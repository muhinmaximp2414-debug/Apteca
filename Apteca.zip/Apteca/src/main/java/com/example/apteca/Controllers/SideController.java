package com.example.apteca.Controllers;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.util.Duration;

import java.io.IOException;
import java.net.URL;

public class SideController {

    @FXML
    public VBox sidebar;
    public Button SidebarButton;

    private boolean isSidebarVisible = true;

    @FXML
    private StackPane contentArea;

    public void onDashBoardButtonClick(ActionEvent actionEvent) {
    }

    public void onMedicineButtonClick(ActionEvent actionEvent) {
        loadPage("/com/example/apteca/views/medicine-view.fxml","/com/example/apteca/styles/PageStyle.css");
    }

    public void onCategoryButtonClick(ActionEvent actionEvent) {
    }

    public void onSuplierButtonClick(ActionEvent actionEvent) {
        loadPage("/com/example/apteca/views/supplier-view.fxml","/com/example/apteca/styles/PageStyle.css");
        //setActiveButton((Button) actionEvent.getSource());
    }

    public void onSaleButtonClick(ActionEvent actionEvent) {
    }

    private void loadPage(String fxmlFileName, String cssFileName) {
        try {
            URL xmlUrl = getClass().getResource(fxmlFileName);

            if (xmlUrl == null) {
                throw new RuntimeException("Файл не найден: " + fxmlFileName);
            }

            URL cssUrl = getClass().getResource(cssFileName);

            if (cssUrl == null) {
                throw new RuntimeException("CSS файл не найден: " + cssFileName);
            }

            FXMLLoader loader = new FXMLLoader(xmlUrl);
            Parent root = loader.load();

            root.getStylesheets().add(cssUrl.toExternalForm());

            contentArea.getChildren().setAll(root);
        } catch (IOException e) {
            showError("Произошла ошибка!");
            e.printStackTrace();
        }
    }


    private void showError (String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText("Error");
        alert.setContentText(message);
        alert.showAndWait();
    }

    public void toggleSidebar(ActionEvent actionEvent) {
        double targetWidth = isSidebarVisible ? 0 : 250;

        Timeline timeline = new Timeline(
                new KeyFrame(Duration.millis(300),
                        new KeyValue(sidebar.prefWidthProperty(), targetWidth))
        );

        timeline.setOnFinished(e -> {
            if (targetWidth == 0) {
                sidebar.setVisible(false);
                if (!SidebarButton.getStyleClass().contains("collapsed")) {
                    SidebarButton.getStyleClass().add("collapsed");
                }
            }
        });

        if (!isSidebarVisible) {
            sidebar.setVisible(true);
            SidebarButton.getStyleClass().remove("collapsed");
        }

        timeline.play();
        isSidebarVisible = !isSidebarVisible;
    }
}
