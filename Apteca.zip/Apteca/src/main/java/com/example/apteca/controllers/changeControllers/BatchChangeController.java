package com.example.apteca.controllers.changeControllers;

import com.example.apteca.db.repository.BatchRepository;
import com.example.apteca.db.repository.MedicineRepository;
import com.example.apteca.db.repository.SupplierRepository;
import com.example.apteca.model.Medicine;
import com.example.apteca.model.MedicineBatch;
import com.example.apteca.model.Supplier;
import com.example.apteca.services.AlertService;
import com.example.apteca.services.SearchableListSelectorService;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.*;

import javafx.scene.control.ListView;



import java.sql.SQLException;
import java.time.LocalDate;


public class BatchChangeController extends ChangeController<MedicineBatch> {

    @FXML private ListView<Medicine> medicineListView;
    @FXML private TextField fieldMedicineSearch;

    @FXML private TextField fieldSupplierSearch;
    @FXML private Label changeBatchTitle;

    @FXML private TextField fieldPurchasePrice;
    @FXML private TextField fieldQuantity;
    @FXML private DatePicker fieldExpirationDate;
    @FXML private DatePicker fieldDeliveryDate;

    @FXML
    private ListView<Supplier> supplierListView;


    @FXML private Label errMedicine;
    @FXML private Label errSupplier;
    @FXML private Label errPurchasePrice;
    @FXML private Label errQuantity;
    @FXML private Label errDeliveryDate;

    @FXML private Button btnSave;

    private final BatchRepository batchRepository = new BatchRepository();
    private final MedicineRepository medicineRepository = new MedicineRepository();
    private final SupplierRepository supplierRepository = new SupplierRepository();

    private SearchableListSelectorService<Supplier> supplierSelector;
    private SearchableListSelectorService<Medicine> medicineSelector;

    @FXML
    private void initialize() {
        setupMedicineSelector();
        setupSupplierSelector();
        fieldDeliveryDate.setValue(LocalDate.now());
    }

    private void setupMedicineSelector() {
        try {
            medicineSelector = new SearchableListSelectorService<>(
                    fieldMedicineSearch,
                    medicineListView,
                    medicineRepository.findAll(),
                    Medicine::getMedicineName,
                    medicine -> hideError(errMedicine)
            );

            medicineSelector.setup();

        } catch (SQLException e) {
            AlertService.showError("Ошибка загрузки лекарств:\n" + e.getMessage());
        }
    }


    private void setupSupplierSelector() {
        try {
            supplierSelector = new SearchableListSelectorService<>(
                    fieldSupplierSearch,
                    supplierListView,
                    supplierRepository.findAll(),
                    Supplier::getSupplierName,
                    supplier -> hideError(errSupplier)
            );

            supplierSelector.setup();

        } catch (SQLException e) {
            AlertService.showError("Ошибка загрузки поставщиков:\n" + e.getMessage());
        }
    }


    @Override
    protected Button getSaveButton() {
        return btnSave;
    }

    @Override
    protected Label getTitleLabel() {
        return changeBatchTitle;
    }

    @Override
    protected Node getAnyNode() {
        return btnSave;
    }

    @Override
    protected String getAddTitle() {
        return "Добавить поставку";
    }

    @Override
    protected String getEditTitle() {
        return "Изменить поставку";
    }

    @Override
    protected boolean validateForm() {
        boolean valid = true;

        hideErrors();

        if (medicineSelector.getSelectedItem() == null) {
            showError(errMedicine);
            valid = false;
        }

        if (supplierSelector.getSelectedItem() == null) {
            showError(errSupplier);
            valid = false;
        }


        try {
            double price = Double.parseDouble(fieldPurchasePrice.getText().trim());

            if (price < 0) {
                showError(errPurchasePrice);
                valid = false;
            }
        } catch (NumberFormatException e) {
            showError(errPurchasePrice);
            valid = false;
        }

        try {
            int quantity = Integer.parseInt(fieldQuantity.getText().trim());

            if (quantity < 0) {
                showError(errQuantity);
                valid = false;
            }
        } catch (NumberFormatException e) {
            showError(errQuantity);
            valid = false;
        }

        if (fieldDeliveryDate.getValue() == null) {
            showError(errDeliveryDate);
            valid = false;
        }

        return valid;
    }

    private void hideErrors() {
        hideError(errMedicine);
        hideError(errSupplier);
        hideError(errPurchasePrice);
        hideError(errQuantity);
        hideError(errDeliveryDate);
    }

    private void showError(Label label) {
        label.setVisible(true);
        label.setManaged(true);
    }

    private void hideError(Label label) {
        label.setVisible(false);
        label.setManaged(false);
    }

    @Override
    protected MedicineBatch createEntity() {
        MedicineBatch batch = new MedicineBatch();
        batch.setIdBatch(0);
        batch.setPrice(0);
        batch.setQuantity(0);
        batch.setDeliveryDate(LocalDate.now());
        return batch;
    }

    @Override
    protected void fillFieldsFromEntity() {
        if (entity.getMedicine() != null) {
            medicineSelector.select(entity.getMedicine());
        }

        if (entity.getSupplier() != null) {
            supplierSelector.select(entity.getSupplier());
        }

        fieldPurchasePrice.setText(String.valueOf(entity.getPrice()));
        fieldQuantity.setText(String.valueOf(entity.getQuantity()));
        fieldExpirationDate.setValue(entity.getExpirationDate());
        fieldDeliveryDate.setValue(entity.getDeliveryDate());
    }

    @Override
    protected void fillEntityFromFields(MedicineBatch batch) {
        batch.setMedicine(medicineSelector.getSelectedItem());
        batch.setSupplier(supplierSelector.getSelectedItem());
        batch.setPrice(Double.parseDouble(fieldPurchasePrice.getText().trim()));
        batch.setQuantity(Integer.parseInt(fieldQuantity.getText().trim()));
        batch.setExpirationDate(fieldExpirationDate.getValue());
        batch.setDeliveryDate(fieldDeliveryDate.getValue());
    }

    @Override
    protected void addEntity(MedicineBatch batch) throws SQLException {
        batchRepository.addToDatabase(batch);
    }

    @Override
    protected void editEntity(MedicineBatch batch) throws SQLException {
        batchRepository.updateInDatabase(batch);
    }
}
