package com.example.apteca.helpers;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

public class AlertHelper {

    private static void applyStyle(Alert alert) {
        String css = AlertHelper.class
                .getResource("/com/example/apteca/styles/AlertsStyle.css")
                .toExternalForm();

        alert.getDialogPane().getStylesheets().add(css);
    }

    public static void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Ошибка");
        alert.setHeaderText(null);
        alert.setContentText(message);
        applyStyle(alert);
        alert.showAndWait();
    }

    public static void showInfo(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Информация");
        alert.setHeaderText(null);
        alert.setContentText(message);
        applyStyle(alert);
        alert.showAndWait();
    }

    public static boolean showConfirmation(String message) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Подтверждение");
        alert.setHeaderText(null);
        alert.setContentText(message);
        applyStyle(alert);

        return alert.showAndWait()
                .orElse(ButtonType.CANCEL) == ButtonType.OK;

    }
}
