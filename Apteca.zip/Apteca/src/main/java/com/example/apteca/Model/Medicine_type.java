package com.example.apteca.Model;

public enum Medicine_type {
}
