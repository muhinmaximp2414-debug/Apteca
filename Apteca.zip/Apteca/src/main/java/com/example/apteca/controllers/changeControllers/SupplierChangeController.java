package com.example.apteca.controllers.changeControllers;

import com.example.apteca.services.AlertService;
import com.example.apteca.model.Supplier;
import com.example.apteca.db.repository.SupplierRepository;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.*;

import java.sql.SQLException;

public class SupplierChangeController extends ChangeController<Supplier> {
    private static final String COUNTRY_CODE = "+373";
    private static final String COUNTRY_CODE_DIGITS = "373";
    private static final int PHONE_DIGITS_COUNT = 8;

    @FXML
    private Button btnSave;
    @FXML
    private TextField fieldName;
    @FXML
    private TextField fieldAddress;
    @FXML
    private TextField fieldEmail;
    @FXML
    private TextField fieldPhone;
    @FXML
    private Label changeSupplierTittle;

    private final SupplierRepository supplierRepository = new SupplierRepository();

    public void initialize() {
        setupPhoneFormatter();
    }

    @Override
    protected Button getSaveButton() {
        return btnSave;
    }

    @Override
    protected Label getTitleLabel() {
        return changeSupplierTittle;
    }

    @Override
    protected Node getAnyNode() {
        return fieldName;
    }

    @Override
    protected String getAddTitle() {
        return "Добавить поставщика";
    }

    @Override
    protected String getEditTitle() {
        return "Изменить поставщика";
    }

    @Override
    protected boolean validateForm() {
        if (isBlank(fieldName) ||
                isBlank(fieldAddress) ||
                isBlank(fieldEmail) ||
                isBlank(fieldPhone)) {

            AlertService.showError("Все поля должны быть заполнены!");
            return false;
        }

        if (getPhoneDigits().length() != PHONE_DIGITS_COUNT) {
            AlertService.showError("Телефон должен содержать ровно 8 цифр!");
            return false;
        }

        return true;
    }

    @Override
    protected Supplier createEntity() {
        return new Supplier();
    }

    @Override
    protected void fillFieldsFromEntity() {
        fieldName.setText(entity.getSupplierName());
        fieldAddress.setText(entity.getSupplierAddress());
        fieldEmail.setText(entity.getSupplierEmail());
        fieldPhone.setText(removeCountryCode(entity.getSupplierPhone()));
    }

    @Override
    protected void fillEntityFromFields(Supplier supplier) {
        supplier.setSupplierName(fieldName.getText().trim());
        supplier.setSupplierAddress(fieldAddress.getText().trim());
        supplier.setSupplierEmail(fieldEmail.getText().trim());
        supplier.setSupplierPhone(COUNTRY_CODE + getPhoneDigits());
    }

    @Override
    protected void addEntity(Supplier supplier) throws SQLException {
        supplierRepository.addToDatabase(supplier);
    }

    @Override
    protected void editEntity(Supplier supplier) throws SQLException {
        supplierRepository.updateInDatabase(supplier);
    }

    private void setupPhoneFormatter() {
        fieldPhone.setTextFormatter(new TextFormatter<String>(change -> {
            String digits = onlyDigits(change.getControlNewText());

            if (digits.length() > PHONE_DIGITS_COUNT) {
                return null;
            }

            String formatted = formatPhone(digits);

            change.setText(formatted);
            change.setRange(0, change.getControlText().length());
            change.setCaretPosition(formatted.length());
            change.setAnchor(formatted.length());

            return change;
        }));
    }

    private String formatPhone(String digits) {
        StringBuilder formatted = new StringBuilder();

        for (int i = 0; i < digits.length(); i++) {
            if (i == 2 || i == 5) {
                formatted.append(" ");
            }

            formatted.append(digits.charAt(i));
        }

        return formatted.toString();
    }

    private String removeCountryCode(String phone) {
        String digits = onlyDigits(phone);

        if (digits.startsWith(COUNTRY_CODE_DIGITS) && digits.length() > PHONE_DIGITS_COUNT) {
            return digits.substring(COUNTRY_CODE_DIGITS.length());
        }

        return digits;
    }

    private String getPhoneDigits() {
        return onlyDigits(fieldPhone.getText());
    }

    private String onlyDigits(String value) {
        return value == null ? "" : value.replaceAll("\\D", "");
    }

    private boolean isBlank(TextField field) {
        return field.getText() == null || field.getText().isBlank();
    }
}