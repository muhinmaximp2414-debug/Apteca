package com.example.apteca.controllers.pageControllers;

import com.example.apteca.services.SearchService;
import com.example.apteca.services.SortingService;
import com.example.apteca.model.Supplier;
import com.example.apteca.repository.SupplierRepository;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Pagination;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.SQLException;
import java.util.List;

public class SupplierController extends PageController<Supplier> {
    @FXML private Pagination pagination;
    @FXML
    private TextField searchField;
    @FXML private TableView<Supplier> supplierTable;
    @FXML private TableColumn<Supplier, String> supplierNameCollumn;
    @FXML private TableColumn<Supplier, String> supplierPhoneColumn;
    @FXML private TableColumn<Supplier, String> supplierEmailColumn;
    @FXML private TableColumn<Supplier, String> supplierAdressColumn;

    private final SupplierRepository supplierRepository = new SupplierRepository();

    @FXML
    public void initialize() {
        initializeBase();
    }

    @FXML
    public void onSupplierAddButtonClick(ActionEvent event) {
        handleAdd();
    }

    @FXML
    public void onSupplierEditButtonClick(ActionEvent event) {
        handleEdit();
    }

    @FXML
    public void onSupplierDeleteButtonClick(ActionEvent event) {
        handleDelete();
    }

    @Override
    protected TableView<Supplier> getTable() {
        return supplierTable;
    }

    @Override
    protected Pagination getPagination() {
        return pagination;
    }

    @Override
    protected TextField getSearchField() {
        return searchField;
    }

    @Override
    protected List<Supplier> findAll() throws SQLException {
        return supplierRepository.findAll();
    }

    @Override
    protected void deleteItem(Supplier supplier) throws SQLException {
        supplierRepository.deleteFromDatabase(supplier);
    }

    @Override
    protected void setupColumns() {
        supplierNameCollumn.setCellValueFactory(new PropertyValueFactory<>("SupplierName"));
        supplierPhoneColumn.setCellValueFactory(new PropertyValueFactory<>("SupplierPhone"));
        supplierEmailColumn.setCellValueFactory(new PropertyValueFactory<>("SupplierEmail"));
        supplierAdressColumn.setCellValueFactory(new PropertyValueFactory<>("SupplierAddress"));
    }

    @Override
    protected void setupSorting() {
        sortHelper = new SortingService<>(
                supplierTable,
                filteredList,
                originalList,
                () -> paginationHelper.loadPage(paginationHelper.getCurrentPageIndex())
        );

        sortHelper.addSortableColumn(supplierNameCollumn, "Название");
        sortHelper.addSortableColumn(supplierPhoneColumn, "Телефон");
        sortHelper.addSortableColumn(supplierEmailColumn, "Email");
        sortHelper.addSortableColumn(supplierAdressColumn, "Адрес");
    }

    @Override
    protected boolean matchesSearch(Supplier supplier, String searchText) {
        return SearchService.containsIgnoreCase(supplier.getSupplierName(), searchText) ||
                SearchService.containsIgnoreCase(supplier.getSupplierPhone(), searchText) ||
                SearchService.containsIgnoreCase(supplier.getSupplierEmail(), searchText) ||
                SearchService.containsIgnoreCase(supplier.getSupplierAddress(), searchText);
    }

    @Override
    protected String getDeleteConfirmationMessage(Supplier supplier) {
        return "Удалить поставщика \"" + supplier.getSupplierName() + "\"?";
    }

    @Override
    protected void openEditor(Supplier supplier) {
        openChangeEditor(
                "/com/example/apteca/views/change-view/supplier-change-view.fxml",
                "/com/example/apteca/styles/addStyle.css",
                "Добавить поставщика",
                "Изменить поставщика",
                supplier
        );
    }

    public void onExportCsvButtonClick(ActionEvent actionEvent) {
        exportCsv(
                "Сохранить поставщиков в CSV",
                "suppliers.csv",
                new String[]{"Название", "Телефон", "Email", "Адрес"},
                List.of(
                        Supplier::getSupplierName,
                        Supplier::getSupplierPhone,
                        Supplier::getSupplierEmail,
                        Supplier::getSupplierAddress
                )
        );
    }
}
