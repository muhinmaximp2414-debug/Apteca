package com.example.apteca.model;

public class Medicine {
    private int idMedicine;
    private String medicineName;
    private String activeIngredient;
    private Category category;
    private MedicineType medicineType;
    private double SalePrice;
    boolean recipe;

    public Medicine(int idMedicine, String medicineName, String activeIngredient, Category category, MedicineType medicineType, double price, boolean recipe) {
        this.idMedicine = idMedicine;
        this.medicineName = medicineName;
        this.activeIngredient = activeIngredient;
        this.category = category;
        this.medicineType = medicineType;
        this.SalePrice = price;
        this.recipe = recipe;
    }

    public Medicine() {
    }

    public int getIdMedicine() {
        return idMedicine;
    }

    public void setIdMedicine(int idMedicine) {
        this.idMedicine = idMedicine;
    }

    public String getMedicineName() {
        return medicineName;
    }

    public void setMedicineName(String medicineName) {
        this.medicineName = medicineName;
    }

    public String getActiveIngredient() {
        return activeIngredient;
    }

    public void setActiveIngredient(String activeIngredient) {
        this.activeIngredient = activeIngredient;
    }

    public Category getCategory() {
        return category;
    }

    public String getCategoryName() {
        return category != null ? category.getDbName() : "";
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public MedicineType getMedicineType() {
        return medicineType;
    }

    public void setMedicineType(MedicineType medicineType) {
        this.medicineType = medicineType;
    }

    public String getMedicineTypeName() {
        return medicineType != null ? medicineType.getDbName() : "";
    }

    public double getSalePrice() {
        return SalePrice;
    }

    public void setSalePrice(double salePrice) {
        this.SalePrice = salePrice;
    }

    public boolean isRecipe() {
        return recipe;
    }

    public void setRecipe(boolean recipe) {
        this.recipe = recipe;
    }
}
