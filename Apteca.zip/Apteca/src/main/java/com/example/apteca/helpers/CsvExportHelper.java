package com.example.apteca.helpers;

import javafx.stage.FileChooser;
import javafx.stage.Window;

import java.io.File;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.function.Function;

public class CsvExportHelper<T> {

    public void export(
            Window ownerWindow,
            String title,
            String initialFileName,
            String[] headers,
            List<T> items,
            List<Function<T, String>> valueExtractors
    ) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle(title);
        fileChooser.setInitialFileName(initialFileName);
        fileChooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("CSV файл", "*.csv")
        );

        File file = fileChooser.showSaveDialog(ownerWindow);

        if (file == null) {
            return;
        }

        try (PrintWriter writer = new PrintWriter(file, StandardCharsets.UTF_8)) {
            writer.println(String.join(",", headers));

            for (T item : items) {
                String line = valueExtractors.stream()
                        .map(extractor -> escapeCsv(extractor.apply(item)))
                        .reduce((a, b) -> a + "," + b)
                        .orElse("");

                writer.println(line);
            }

            AlertHelper.showInfo("CSV файл успешно сохранён!");

        } catch (Exception e) {
            AlertHelper.showError("Ошибка сохранения CSV:\n" + e.getMessage());
        }
    }

    private String escapeCsv(String value) {
        if (value == null) {
            return "";
        }

        String escaped = value.replace("\"", "\"\"");

        if (escaped.contains(",") || escaped.contains("\"") || escaped.contains("\n")) {
            return "\"" + escaped + "\"";
        }

        return escaped;
    }
}
