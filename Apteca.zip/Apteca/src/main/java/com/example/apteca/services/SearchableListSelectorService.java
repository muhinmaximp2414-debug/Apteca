package com.example.apteca.services;

import javafx.animation.PauseTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.util.Duration;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;

public class SearchableListSelectorService<T> {
    private final TextField searchField;
    private final ListView<T> listView;
    private final ObservableList<T> allItems;
    private final Function<T, String> textExtractor;
    private final Consumer<T> onSelected;
    private final SearchPopup<T> searchPopup;

    private T selectedItem;
    private boolean internalChange;

    public SearchableListSelectorService(
            TextField searchField,
            ListView<T> listView,
            List<T> items,
            Function<T, String> textExtractor,
            Consumer<T> onSelected
    ) {
        this.searchField = searchField;
        this.listView = listView;
        this.allItems = FXCollections.observableArrayList(items);
        this.textExtractor = textExtractor;
        this.onSelected = onSelected;
        this.searchPopup = new SearchPopup<>(searchField, listView);
    }

    public void setup() {
        listView.setItems(allItems);

        listView.setCellFactory(list -> new ListCell<>() {
            @Override
            protected void updateItem(T item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : safeText(textExtractor.apply(item)));
            }
        });

        searchField.textProperty().addListener((obs, oldValue, newValue) -> {
            if (internalChange) {
                return;
            }

            selectedItem = null;
            filter(newValue);
        });

        searchField.focusedProperty().addListener((obs, wasFocused, isFocused) -> {
            if (isFocused && selectedItem == null) {
                filter(searchField.getText());
            }
        });

        listView.setOnMouseClicked(event -> {
            T item = listView.getSelectionModel().getSelectedItem();

            if (item != null) {
                select(item);
            }
        });
    }

    public T getSelectedItem() {
        return selectedItem;
    }

    public void select(T item) {
        selectedItem = item;

        internalChange = true;
        searchField.setText(safeText(textExtractor.apply(item)));
        searchField.positionCaret(searchField.getText().length());
        internalChange = false;

        listView.getSelectionModel().clearSelection();
        searchPopup.hide();
        searchField.requestFocus();

        if (onSelected != null) {
            onSelected.accept(item);
        }
    }

    public void clear() {
        selectedItem = null;

        internalChange = true;
        searchField.clear();
        internalChange = false;

        listView.setItems(allItems);
        searchPopup.hide();
    }

    private void filter(String text) {
        String searchText = text == null ? "" : text.trim().toLowerCase();

        ObservableList<T> filteredItems = allItems.filtered(item ->
                searchText.isEmpty() ||
                        safeText(textExtractor.apply(item)).toLowerCase().contains(searchText)
        );

        listView.setItems(filteredItems);

        if (filteredItems.isEmpty()) {
            searchPopup.hide();
        } else {
            searchPopup.show();
        }
    }

    private String safeText(String value) {
        return value == null ? "" : value;
    }
}