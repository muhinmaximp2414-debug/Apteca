package com.example.apteca.db.repository;

import java.sql.SQLException;
import java.util.List;

public interface Repository<T> {
    List<T> findAll() throws SQLException;

    void addToDatabase(T item) throws SQLException;

    void updateInDatabase(T item) throws SQLException;

    void deleteFromDatabase(T item) throws SQLException;
}
