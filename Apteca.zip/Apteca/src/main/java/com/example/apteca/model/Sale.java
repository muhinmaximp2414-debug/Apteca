package com.example.apteca.model;

import java.time.LocalDateTime;

public class Sale {
    private MedicineBatch medicineBatch;
    private LocalDateTime saleDate;
    private int saleQuantity;
    private double price;

    public Sale(MedicineBatch medicineBatch, LocalDateTime saleDate, int saleQuantity, double price) {
        this.medicineBatch = medicineBatch;
        this.saleDate = saleDate;
        this.saleQuantity = saleQuantity;
        this.price = price;
    }

    public MedicineBatch getMedicineBatch() {
        return medicineBatch;
    }

    public void setMedicineBatch(MedicineBatch medicineBatch) {
        this.medicineBatch = medicineBatch;
    }

    public LocalDateTime getSaleDate() {
        return saleDate;
    }

    public void setSaleDate(LocalDateTime saleDate) {
        this.saleDate = saleDate;
    }

    public int getSaleQuantity() {
        return saleQuantity;
    }

    public void setSaleQuantity(int saleQuantity) {
        this.saleQuantity = saleQuantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}
