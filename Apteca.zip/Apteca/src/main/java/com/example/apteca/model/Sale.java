package com.example.apteca.model;

import java.time.LocalDateTime;

public class Sale {
    private Medicine medicine;
    private LocalDateTime sale_date;
    private int sale_quantity;
}
