package com.example.apteca.model;

public enum Category {
}
