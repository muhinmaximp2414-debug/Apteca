package com.example.apteca.model;

public enum Category implements DbNamedEnum {
        PAINKILLERS( "Обезболивающие"),
        ANTIBIOTICS( "Антибиотики"),
        VITAMINS( "Витамины"),
        ANTIVIRALS( "Противовирусные"),
        ANTISEPTICS( "Антисептики");

        private final String dbName;

        Category(String dbName) {
            this.dbName = dbName;
        }

        @Override
        public String getDbName() {
            return dbName;
        }

        public static Category fromDbName(String dbName) {
            for (Category category : values()) {
                if (category.dbName.equals(dbName)) {
                    return category;
                }
            }
            throw new IllegalArgumentException("Неизвестная категория: " + dbName);
        }
}
