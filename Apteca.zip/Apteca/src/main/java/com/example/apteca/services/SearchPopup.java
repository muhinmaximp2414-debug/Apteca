package com.example.apteca.services;

import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.stage.Popup;

public class SearchPopup<T> {
    private final TextField ownerField;
    private final ListView<T> listView;
    private final Popup popup = new Popup();

    public SearchPopup(TextField ownerField, ListView<T> listView) {
        this.ownerField = ownerField;
        this.listView = listView;

        setupPopup();
    }

    private void setupPopup() {
        popup.getContent().setAll(listView);
        popup.setAutoHide(true);

        listView.setPrefHeight(140);
        listView.setMaxHeight(140);
        listView.setVisible(true);
        listView.setManaged(true);
    }

    public void show() {
        if (ownerField.getScene() == null || ownerField.getScene().getWindow() == null) {
            return;
        }

        double x = ownerField.localToScreen(0, 0).getX();
        double y = ownerField.localToScreen(0, ownerField.getHeight()).getY();

        listView.setPrefWidth(ownerField.getWidth());

        if (!popup.isShowing()) {
            popup.show(ownerField, x, y);
        }
    }

    public void hide() {
        popup.hide();
    }

    public boolean isShowing() {
        return popup.isShowing();
    }
}
