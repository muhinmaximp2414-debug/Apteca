package com.example.apteca.Model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Sale {
    private Medicine medicine;
    private LocalDateTime sale_date;
    private int sale_quantity;
}
