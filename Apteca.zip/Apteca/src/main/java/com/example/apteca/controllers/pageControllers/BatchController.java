package com.example.apteca.controllers.pageControllers;

import com.example.apteca.model.MedicineBatch;
import com.example.apteca.db.repository.BatchRepository;
import com.example.apteca.services.SearchService;
import com.example.apteca.services.SortingService;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

public class BatchController extends PageController<MedicineBatch> {

    @FXML private Pagination pagination;
    @FXML private TextField searchField;

    @FXML private TableView<MedicineBatch> batchTable;

    @FXML private ComboBox<String> stockFilter;
    @FXML private ComboBox<String> expirationFilter;

    @FXML private TextField purchasePriceFromFilter;
    @FXML private TextField purchasePriceToFilter;
    @FXML private Slider purchasePriceSlider;

    @FXML private DatePicker deliveryDateFromFilter;
    @FXML private DatePicker deliveryDateToFilter;

    @FXML private TableColumn<MedicineBatch, String> medicineNameColumn;
    @FXML private TableColumn<MedicineBatch, String> supplierNameColumn;
    @FXML private TableColumn<MedicineBatch, BigDecimal> purchasePriceColumn;
    @FXML private TableColumn<MedicineBatch, Integer> quantityColumn;
    @FXML private TableColumn<MedicineBatch, Date> expirationDateColumn;
    @FXML private TableColumn<MedicineBatch, Date> deliveryDateColumn;

    private final BatchRepository batchRepository = new BatchRepository();

    @FXML
    public void initialize() {
        initializeBase();
        setupFilters();
    }

    @FXML
    public void onBatchAddButtonClick(ActionEvent event) {
        handleAdd();
    }

    @FXML
    public void onBatchEditButtonClick(ActionEvent event) {
        handleEdit();
    }

    @FXML
    public void onBatchDeleteButtonClick(ActionEvent event) {
        handleDelete();
    }

    @FXML
    public void onExportCsvButtonClick(ActionEvent event) {
        exportCsv(
                "Сохранить поставки в CSV",
                "batches.csv",
                new String[]{
                        "Лекарство",
                        "Поставщик",
                        "Цена закупки",
                        "Количество",
                        "Годен до",
                        "Дата закупки"
                },
                List.of(
                        MedicineBatch::getMedicineName,
                        MedicineBatch::getSupplierName,
                        batch -> String.valueOf(batch.getPrice()),
                        batch -> String.valueOf(batch.getQuantity()),
                        batch -> String.valueOf(batch.getExpirationDate()),
                        batch -> String.valueOf(batch.getDeliveryDate())
                )
        );
    }

    @Override
    protected TableView<MedicineBatch> getTable() {
        return batchTable;
    }

    @Override
    protected Pagination getPagination() {
        return pagination;
    }

    @Override
    protected TextField getSearchField() {
        return searchField;
    }

    @Override
    protected List<MedicineBatch> findAll() throws SQLException {
        return batchRepository.findAll();
    }

    @Override
    protected void deleteItem(MedicineBatch batch) throws SQLException {
        batchRepository.deleteFromDatabase(batch);
    }

    @Override
    protected void setupColumns() {
        medicineNameColumn.setCellValueFactory(new PropertyValueFactory<>("MedicineName"));
        supplierNameColumn.setCellValueFactory(new PropertyValueFactory<>("SupplierName"));
        purchasePriceColumn.setCellValueFactory(new PropertyValueFactory<>("Price"));
        quantityColumn.setCellValueFactory(new PropertyValueFactory<>("Quantity"));
        expirationDateColumn.setCellValueFactory(new PropertyValueFactory<>("ExpirationDate"));
        deliveryDateColumn.setCellValueFactory(new PropertyValueFactory<>("DeliveryDate"));
    }

    @Override
    protected void setupSorting() {
        sortHelper = new SortingService<>(
                batchTable,
                filteredList,
                originalList,
                () -> paginationHelper.loadPage(paginationHelper.getCurrentPageIndex())
        );

        sortHelper.addSortableColumn(medicineNameColumn, "Лекарство");
        sortHelper.addSortableColumn(supplierNameColumn, "Поставщик");
        sortHelper.addSortableColumn(purchasePriceColumn, "Цена закупки");
        sortHelper.addSortableColumn(quantityColumn, "Количество");
        sortHelper.addSortableColumn(expirationDateColumn, "Годен до");
        sortHelper.addSortableColumn(deliveryDateColumn, "Дата закупки");
    }

    @Override
    protected boolean matchesSearch(MedicineBatch batch, String searchText) {
        return SearchService.containsIgnoreCase(batch.getMedicineName(), searchText) ||
                SearchService.containsIgnoreCase(batch.getSupplierName(), searchText);
    }

    @Override
    protected String getDeleteConfirmationMessage(MedicineBatch batch) {
        return "Удалить поставку \"" + batch.getMedicineName() + "\" от поставщика \"" +
                batch.getSupplierName() + "\"?";
    }

    @Override
    protected void openEditor(MedicineBatch batch) {
        openChangeEditor(
                "/com/example/apteca/views/change-view/batch-change-view.fxml",
                "/com/example/apteca/styles/addStyle.css",
                "Добавить поставку",
                "Изменить поставку",
                batch
        );
    }

    private static final double MIN_PRICE = 0;
    private static final double MAX_PRICE = 500;

    private void setupFilters() {
        setupComboFilter(
                stockFilter,
                List.of("Все", "Есть на складе", "Закончились")
        );

        setupComboFilter(
                expirationFilter,
                List.of("Все", "Годные", "Скоро истекают", "Просроченные")
        );

        setupPriceFilter();
        setupDateFilter();

        applySearchAndFilters();
    }

    private void setupPriceFilter() {
        purchasePriceSlider.setMin(MIN_PRICE);
        purchasePriceSlider.setMax(MAX_PRICE);
        purchasePriceSlider.setValue(MAX_PRICE);

        purchasePriceFromFilter.setText(String.valueOf((int) MIN_PRICE));
        purchasePriceToFilter.setText(String.valueOf((int) MAX_PRICE));

        purchasePriceSlider.valueProperty().addListener((obs, oldValue, newValue) -> {
            purchasePriceToFilter.setText(String.valueOf(newValue.intValue()));
            applySearchAndFilters();
        });

        purchasePriceFromFilter.textProperty().addListener((obs, oldValue, newValue) ->
                applySearchAndFilters()
        );

        purchasePriceToFilter.textProperty().addListener((obs, oldValue, newValue) -> {
            double value = parseDoubleOrDefault(newValue, MAX_PRICE);

            if (value >= MIN_PRICE && value <= MAX_PRICE) {
                purchasePriceSlider.setValue(value);
            }

            applySearchAndFilters();
        });
    }

    private void setupDateFilter() {
        deliveryDateFromFilter.valueProperty().addListener((obs, oldValue, newValue) ->
                applySearchAndFilters()
        );

        deliveryDateToFilter.valueProperty().addListener((obs, oldValue, newValue) ->
                applySearchAndFilters()
        );
    }

    @Override
    protected boolean matchesFilters(MedicineBatch batch) {
        return matchesStockFilter(batch)
                && matchesExpirationFilter(batch)
                && matchesPurchasePriceFilter(batch)
                && matchesDeliveryDateFilter(batch);
    }

    private boolean matchesStockFilter(MedicineBatch batch) {
        String value = stockFilter.getValue();

        if (value == null || value.equals(ALL_FILTER)) {
            return true;
        }

        return switch (value) {
            case "Есть на складе" -> batch.getQuantity() > 0;
            case "Закончились" -> batch.getQuantity() == 0;
            default -> true;
        };
    }

    private boolean matchesPurchasePriceFilter(MedicineBatch batch) {
        double price = batch.getPrice();

        double from = parseDoubleOrDefault(purchasePriceFromFilter.getText(), MIN_PRICE);
        double to = parseDoubleOrDefault(purchasePriceToFilter.getText(), MAX_PRICE);

        return price >= from && price <= to;
    }

    private boolean matchesExpirationFilter(MedicineBatch batch) {
        String value = expirationFilter.getValue();
        LocalDate expirationDate = batch.getExpirationDate();

        if (value == null || value.equals(ALL_FILTER)) {
            return true;
        }

        if (expirationDate == null) {
            return false;
        }

        LocalDate today = LocalDate.now();

        return switch (value) {
            case "Годные" -> expirationDate.isAfter(today);
            case "Скоро истекают" ->
                    !expirationDate.isBefore(today) &&
                            !expirationDate.isAfter(today.plusMonths(1));
            case "Просроченные" -> expirationDate.isBefore(today);
            default -> true;
        };
    }

    private boolean matchesDeliveryDateFilter(MedicineBatch batch) {
        LocalDate deliveryDate = batch.getDeliveryDate();

        if (deliveryDate == null) {
            return false;
        }

        LocalDate from = deliveryDateFromFilter.getValue();
        LocalDate to = deliveryDateToFilter.getValue();

        boolean afterFrom = from == null || !deliveryDate.isBefore(from);
        boolean beforeTo = to == null || !deliveryDate.isAfter(to);

        return afterFrom && beforeTo;
    }

    private double parseDoubleOrDefault(String value, double defaultValue) {
        try {
            if (value == null || value.isBlank()) {
                return defaultValue;
            }

            return Double.parseDouble(value.trim());
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    public void onResetFiltersButtonClick(ActionEvent event) {
        resetComboFilter(stockFilter);
        resetComboFilter(expirationFilter);

        purchasePriceFromFilter.setText(String.valueOf((int) MIN_PRICE));
        purchasePriceToFilter.setText(String.valueOf((int) MAX_PRICE));
        purchasePriceSlider.setValue(MAX_PRICE);

        deliveryDateFromFilter.setValue(null);
        deliveryDateToFilter.setValue(null);

        applySearchAndFilters();
    }
}
