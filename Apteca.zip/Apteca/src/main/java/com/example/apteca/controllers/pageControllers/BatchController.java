package com.example.apteca.controllers.pageControllers;

import com.example.apteca.model.MedicineBatch;
import com.example.apteca.repository.BatchRepository;
import com.example.apteca.services.SearchService;
import com.example.apteca.services.SortingService;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Pagination;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

public class BatchController extends PageController<MedicineBatch> {

    @FXML private Pagination pagination;
    @FXML private TextField searchField;

    @FXML private TableView<MedicineBatch> batchTable;

    @FXML private TableColumn<MedicineBatch, String> medicineNameColumn;
    @FXML private TableColumn<MedicineBatch, String> supplierNameColumn;
    @FXML private TableColumn<MedicineBatch, BigDecimal> purchasePriceColumn;
    @FXML private TableColumn<MedicineBatch, Integer> quantityColumn;
    @FXML private TableColumn<MedicineBatch, Date> expirationDateColumn;
    @FXML private TableColumn<MedicineBatch, Date> deliveryDateColumn;

    private final BatchRepository batchRepository = new BatchRepository();

    @FXML
    public void initialize() {
        initializeBase();
    }

    @FXML
    public void onBatchAddButtonClick(ActionEvent event) {
        handleAdd();
    }

    @FXML
    public void onBatchEditButtonClick(ActionEvent event) {
        handleEdit();
    }

    @FXML
    public void onBatchDeleteButtonClick(ActionEvent event) {
        handleDelete();
    }

    @FXML
    public void onExportCsvButtonClick(ActionEvent event) {
        exportCsv(
                "Сохранить поставки в CSV",
                "batches.csv",
                new String[]{
                        "Лекарство",
                        "Поставщик",
                        "Цена закупки",
                        "Количество",
                        "Годен до",
                        "Дата закупки"
                },
                List.of(
                        MedicineBatch::getMedicineName,
                        MedicineBatch::getSupplierName,
                        batch -> String.valueOf(batch.getPrice()),
                        batch -> String.valueOf(batch.getQuantity()),
                        batch -> String.valueOf(batch.getExpirationDate()),
                        batch -> String.valueOf(batch.getDeliveryDate())
                )
        );
    }

    @Override
    protected TableView<MedicineBatch> getTable() {
        return batchTable;
    }

    @Override
    protected Pagination getPagination() {
        return pagination;
    }

    @Override
    protected TextField getSearchField() {
        return searchField;
    }

    @Override
    protected List<MedicineBatch> findAll() throws SQLException {
        return batchRepository.findAll();
    }

    @Override
    protected void deleteItem(MedicineBatch batch) throws SQLException {
        batchRepository.deleteFromDatabase(batch);
    }

    @Override
    protected void setupColumns() {
        medicineNameColumn.setCellValueFactory(new PropertyValueFactory<>("MedicineName"));
        supplierNameColumn.setCellValueFactory(new PropertyValueFactory<>("SupplierName"));
        purchasePriceColumn.setCellValueFactory(new PropertyValueFactory<>("PurchasePrice"));
        quantityColumn.setCellValueFactory(new PropertyValueFactory<>("Quantity"));
        expirationDateColumn.setCellValueFactory(new PropertyValueFactory<>("ExpirationDate"));
        deliveryDateColumn.setCellValueFactory(new PropertyValueFactory<>("DeliveryDate"));
    }

    @Override
    protected void setupSorting() {
        sortHelper = new SortingService<>(
                batchTable,
                filteredList,
                originalList,
                () -> paginationHelper.loadPage(paginationHelper.getCurrentPageIndex())
        );

        sortHelper.addSortableColumn(medicineNameColumn, "Лекарство");
        sortHelper.addSortableColumn(supplierNameColumn, "Поставщик");
        sortHelper.addSortableColumn(purchasePriceColumn, "Цена закупки");
        sortHelper.addSortableColumn(quantityColumn, "Количество");
        sortHelper.addSortableColumn(expirationDateColumn, "Годен до");
        sortHelper.addSortableColumn(deliveryDateColumn, "Дата закупки");
    }

    @Override
    protected boolean matchesSearch(MedicineBatch batch, String searchText) {
        return SearchService.containsIgnoreCase(batch.getMedicineName(), searchText) ||
                SearchService.containsIgnoreCase(batch.getSupplierName(), searchText);
    }

    @Override
    protected String getDeleteConfirmationMessage(MedicineBatch batch) {
        return "Удалить поставку \"" + batch.getMedicineName() + "\" от поставщика \"" +
                batch.getSupplierName() + "\"?";
    }

    @Override
    protected void openEditor(MedicineBatch batch) {
        openChangeEditor(
                "/com/example/apteca/views/change-view/batch-change-view.fxml",
                "/com/example/apteca/styles/addStyle.css",
                "Добавить поставку",
                "Изменить поставку",
                batch
        );
    }
}
