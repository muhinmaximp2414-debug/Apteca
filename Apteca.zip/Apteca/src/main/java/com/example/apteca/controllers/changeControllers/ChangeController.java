package com.example.apteca.controllers.changeControllers;

import com.example.apteca.services.AlertService;
import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.sql.SQLException;

public abstract class ChangeController<T> {
    protected boolean editMode;
    protected T entity;

    protected abstract Button getSaveButton();
    protected abstract Label getTitleLabel();
    protected abstract Node getAnyNode();

    protected abstract String getAddTitle();
    protected abstract String getEditTitle();

    protected abstract boolean validateForm();
    protected abstract T createEntity();
    protected abstract void fillFieldsFromEntity();
    protected abstract void fillEntityFromFields(T entity) throws Exception;
    protected abstract void addEntity(T entity) throws SQLException;
    protected abstract void editEntity(T entity) throws SQLException;

    public void setEntity(T entity) {
        this.entity = entity;
        this.editMode = entity != null;

        updateWindowMode();

        if (editMode) {
            fillFieldsFromEntity();
        }
    }

    public void onSaveButtonClick(ActionEvent actionEvent) {
        try {
            if (!validateForm()) {
                return;
            }

            if (editMode) {
                fillEntityFromFields(entity);
                editEntity(entity);
            } else {
                T newEntity = createEntity();
                fillEntityFromFields(newEntity);
                addEntity(newEntity);
            }

            close();

        } catch (SQLException e) {
            AlertService.showError("Ошибка базы данных:\n" + e.getMessage());
        } catch (Exception e) {
            AlertService.showError("Ошибка:\n" + e.getMessage());
        }
    }

    public void onCancelButtonClick(ActionEvent actionEvent) {
        close();
    }

    protected void updateWindowMode() {
        getTitleLabel().setText(editMode ? getEditTitle() : getAddTitle());
        getSaveButton().setText(editMode ? "Сохранить" : "Добавить");
    }

    protected void close() {
        ((Stage) getAnyNode().getScene().getWindow()).close();
    }
}

