package com.example.apteca.controllers.pageControllers;

import com.example.apteca.controllers.changeControllers.SupplierChangeController;
import com.example.apteca.helpers.*;
import com.example.apteca.model.Supplier;
import com.example.apteca.repository.SupplierRepository;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;


import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.util.List;

import static com.example.apteca.helpers.SearchHelper.containsIgnoreCase;
public class Supplier_controller {

    @FXML private Pagination pagination;
    @FXML private TextField searchField;

    private SortingHelper<Supplier> sortHelper;
    private PaginationHelper<Supplier> paginationHelper;
    private SearchHelper<Supplier> searchHelper;
    private final CsvExportHelper<Supplier> csvExportHelper = new CsvExportHelper<>();



    @FXML private  TableView <Supplier> supplierTable;
    @FXML private  TableColumn <Supplier,String> supplierNameCollumn;
    @FXML private  TableColumn <Supplier,String> supplierPhoneColumn;
    @FXML private  TableColumn <Supplier,String> supplierEmailColumn;
    @FXML private  TableColumn <Supplier,String> supplierAdressColumn;

    private final ObservableList<Supplier> supplierList = FXCollections.observableArrayList();
    private final ObservableList<Supplier> originalSupplierList = FXCollections.observableArrayList();
    private final ObservableList<Supplier> filteredSupplierList = FXCollections.observableArrayList();

    private final SupplierRepository supplierRepository = new SupplierRepository();


    public void initialize (){

        setupTableColumns();
        setupTableView();

        loadDataFromDatabase();
        setupPaginationHelper();
        setupTableSorting();
        setupSearch();
        paginationHelper.refresh();

    }

    public void onSupplierAddButtonClick(ActionEvent actionEvent) {
        openEditor(null);
    }

    public void onSupplierEditButtonClick(ActionEvent actionEvent) {
        Supplier selectedSupplier = supplierTable.getSelectionModel().getSelectedItem();

        if (selectedSupplier == null) {
            AlertHelper.showError("Выберите поставщика!");
            return;
        }

        openEditor(selectedSupplier);
    }

    public void onSupplierDeleteButtonClick(ActionEvent actionEvent) {
        Supplier selectedSupplier = supplierTable.getSelectionModel().getSelectedItem();
        if (selectedSupplier == null) {
            AlertHelper.showError("Выберите поставщика");
            return;
        }

        boolean confirmed = AlertHelper.showConfirmation(
                "Удалить поставщика \"" + selectedSupplier.getSupplierName() + "\"?"
        );

        if (!confirmed) {
            return;
        }
        try {
                supplierRepository.deleteSupplierFromDatabase(selectedSupplier);
                refreshTableData();
            }  catch (SQLException e) {
                AlertHelper.showError("Ошибка удаления поставщика:\n" + e.getMessage());
            }
    }

    public void onExportCsvButtonClick(ActionEvent actionEvent) {
        csvExportHelper.export(
                supplierTable.getScene().getWindow(),
                "Сохранить поставщиков в CSV",
                "suppliers.csv",
                new String[]{"Название", "Телефон", "Email", "Адрес"},
                filteredSupplierList,
                List.of(
                        Supplier::getSupplierName,
                        Supplier::getSupplierPhone,
                        Supplier::getSupplierEmail,
                        Supplier::getSupplierAddress
                )
        );
    }

    private void loadDataFromDatabase() {
        try {
            supplierList.setAll(supplierRepository.findAll());

            if (searchHelper != null) {
                searchHelper.applySearch();
            } else {
                filteredSupplierList.setAll(supplierList);
            }
            originalSupplierList.setAll(filteredSupplierList);

        } catch (SQLException e) {
            AlertHelper.showError("Ошибка загрузки базы данных: " + e.getMessage());
        }
    }

    public void openEditor(Supplier supplier) {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/com/example/apteca/views/change-view/supplier-add-view.fxml")
            );

            Parent root = loader.load();

            SupplierChangeController supplierChangeController = loader.getController();
            supplierChangeController.setEntity(supplier);
            Scene scene = new Scene(root);
            scene.getStylesheets().add(getClass().getResource("/com/example/apteca/styles/addStyle.css").toExternalForm());


            Stage stage = new Stage();
            stage.resizableProperty().setValue(Boolean.FALSE);
            stage.setTitle(supplier == null ? "Добавить поставщика" : "Изменить поставщика");
            stage.setScene(scene);

            stage.initModality(Modality.APPLICATION_MODAL);

            stage.showAndWait();

            refreshTableData();

        } catch (IOException e) {
            AlertHelper.showError("Ошибка открытия окна: " + e.getMessage());
        }
    }

    private void setupTableColumns() {
        supplierNameCollumn.setCellValueFactory(new PropertyValueFactory<>("SupplierName"));
        supplierPhoneColumn.setCellValueFactory(new PropertyValueFactory<>("SupplierPhone"));
        supplierEmailColumn.setCellValueFactory(new PropertyValueFactory<>("SupplierEmail"));
        supplierAdressColumn.setCellValueFactory(new PropertyValueFactory<>("SupplierAddress"));
    }

    private void setupTableView() {
        supplierTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        supplierTable.setFixedCellSize(25);
    }

    private void setupPaginationHelper() {
        paginationHelper = new PaginationHelper<>(
                pagination,
                supplierTable,
                filteredSupplierList,
                12
        );

        paginationHelper.setup();
        paginationHelper.setupDynamicRowCount();
    }

    private void setupTableSorting() {
        sortHelper = new SortingHelper<>(
                supplierTable,
                filteredSupplierList,
                originalSupplierList,
                () -> paginationHelper.loadPage(paginationHelper.getCurrentPageIndex())
        );

        sortHelper.addSortableColumn(supplierNameCollumn, "Название");
        sortHelper.addSortableColumn(supplierPhoneColumn, "Телефон");
        sortHelper.addSortableColumn(supplierEmailColumn, "Email");
        sortHelper.addSortableColumn(supplierAdressColumn, "Адрес");
    }

    private void refreshTableData() {
        loadDataFromDatabase();

        refreshFilteredTable();
    }

    private void setupSearch() {
        searchHelper = new SearchHelper<>(
                searchField,
                supplierList,
                filteredSupplierList,
                this::supplierMatchesSearch,
                this::refreshFilteredTable
        );

        searchHelper.setup();
    }

    private void refreshFilteredTable() {
        originalSupplierList.setAll(filteredSupplierList);

        if (sortHelper != null) {
            sortHelper.applyCurrentSort();
        }

        paginationHelper.refresh();
        supplierTable.refresh();
    }

    private boolean supplierMatchesSearch(Supplier supplier, String searchText) {
        return containsIgnoreCase(supplier.getSupplierName(), searchText) ||
                containsIgnoreCase(supplier.getSupplierPhone(), searchText) ||
                containsIgnoreCase(supplier.getSupplierEmail(), searchText) ||
                containsIgnoreCase(supplier.getSupplierAddress(), searchText);
    }
}
