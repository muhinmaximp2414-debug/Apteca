package com.example.apteca.controllers.pageControllers;

import com.example.apteca.controllers.changeControllers.SupplierAddController;
import com.example.apteca.model.Supplier;
import com.example.apteca.helpers.AlertHelper;
import com.example.apteca.helpers.PaginationHelper;
import com.example.apteca.helpers.SortingHelper;
import com.example.apteca.repository.SupplierRepository;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;


import java.io.IOException;
import java.sql.SQLException;

public class Supplier_controller {

    public Pagination pagination;

    private SortingHelper<Supplier> sortHelper;
    private PaginationHelper<Supplier> paginationHelper;

    public TableView <Supplier> supplierTable;
    public TableColumn <Supplier,String> supplierNameCollumn;
    public TableColumn <Supplier,String> supplierPhoneColumn;
    public TableColumn <Supplier,String> supplierEmailColumn;
    public TableColumn <Supplier,String> supplierAdressColumn;

    private final ObservableList<Supplier> supplierList = FXCollections.observableArrayList();
    private final ObservableList<Supplier> originalSupplierList = FXCollections.observableArrayList();
    private final SupplierRepository supplierRepository = new SupplierRepository();


    public void initialize (){

        supplierNameCollumn.setCellValueFactory(new PropertyValueFactory<>("SupplierName"));
        supplierPhoneColumn.setCellValueFactory(new PropertyValueFactory<>("SupplierPhone"));
        supplierEmailColumn.setCellValueFactory(new PropertyValueFactory<>("SupplierEmail"));
        supplierAdressColumn.setCellValueFactory(new PropertyValueFactory<>("SupplierAddress"));

        supplierTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        supplierTable.setFixedCellSize(25);

        loadDataFromDatabase();
        setupPaginationHelper();
        setupTableSorting();

    }

    public void onSupplierAddButtonClick(ActionEvent actionEvent) {
        openEditor(null);
    }

    public void onSupplierEditButtonClick(ActionEvent actionEvent) {
        Supplier selectedSupplier = supplierTable.getSelectionModel().getSelectedItem();

        if (selectedSupplier == null) {
            AlertHelper.showError("Выберите поставщика!");
            return;
        }

        openEditor(selectedSupplier);
    }

    public void onSupplierDeleteButtonClick(ActionEvent actionEvent) {
        Supplier selectedSupplier = supplierTable.getSelectionModel().getSelectedItem();
        if (selectedSupplier == null) {
            AlertHelper.showError("Выберите поставщика");
            return;
        }

        boolean confirmed = AlertHelper.showConfirmation(
                "Удалить поставщика \"" + selectedSupplier.getSupplierName() + "\"?"
        );

        if (!confirmed) {
            return;
        }

        try {
                supplierRepository.deleteSupplierFromDatabase(selectedSupplier);
                refreshTableData();
            }  catch (SQLException e) {
                AlertHelper.showError("Ошибка удаления поставщика:\n" + e.getMessage());
            }
    }

    private void loadDataFromDatabase() {
        try {
            supplierList.setAll(supplierRepository.findAll());
            originalSupplierList.setAll(supplierList);
        } catch (SQLException e) {
            AlertHelper.showError("Ошибка загрузки базы данных: " + e.getMessage());
        }
    }

    public void openEditor(Supplier supplier) {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/com/example/apteca/views/change-view/supplier-add-view.fxml")
            );

            Parent root = loader.load();

            SupplierAddController controller = loader.getController();
            controller.setSupplier(supplier);
            //controller.setAll(supplierList);
            Scene scene = new Scene(root);
            scene.getStylesheets().add(getClass().getResource("/com/example/apteca/styles/addStyle.css").toExternalForm());


            Stage stage = new Stage();
            stage.resizableProperty().setValue(Boolean.FALSE);
            stage.setTitle(supplier == null ? "Добавить поставщика" : "Изменить поставщика");
            stage.setScene(scene);

            stage.initModality(Modality.APPLICATION_MODAL);

            stage.showAndWait();

            refreshTableData();

        } catch (IOException e) {
            AlertHelper.showError("Ошибка открытия окна: " + e.getMessage());
        }
    }

    private void setupPaginationHelper() {
        paginationHelper = new PaginationHelper<>(
                pagination,
                supplierTable,
                supplierList,
                12
        );

        paginationHelper.setup();
        paginationHelper.setupDynamicRowCount();
    }

    private void setupTableSorting() {
        sortHelper = new SortingHelper<>(
                supplierTable,
                supplierList,
                originalSupplierList,
                () -> paginationHelper.loadPage(paginationHelper.getCurrentPageIndex())
        );

        sortHelper.addSortableColumn(supplierNameCollumn, "Название");
        sortHelper.addSortableColumn(supplierPhoneColumn, "Телефон");
        sortHelper.addSortableColumn(supplierEmailColumn, "Email");
        sortHelper.addSortableColumn(supplierAdressColumn, "Адрес");
    }

    private void refreshTableData() {
        loadDataFromDatabase();

        if (sortHelper != null) {
            sortHelper.applyCurrentSort();
        }

        paginationHelper.refresh();
        supplierTable.refresh();
    }
}
