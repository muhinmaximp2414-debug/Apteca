package com.example.apteca.services;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Pagination;
import javafx.scene.control.TableView;
import javafx.scene.layout.VBox;
import javafx.util.Duration;

public class PaginationService<T> {
    private final Pagination pagination;
    private final TableView<T> tableView;
    private final ObservableList<T> fullList;

    private int rowsPerPage;
    private Timeline resizeDebouncer;
    private int pendingRowsPerPage;

    public PaginationService(
            Pagination pagination,
            TableView<T> tableView,
            ObservableList<T> fullList,
            int rowsPerPage
    ) {
        this.pagination = pagination;
        this.tableView = tableView;
        this.fullList = fullList;
        this.rowsPerPage = rowsPerPage;
    }

    public void setup() {
        updatePageCount();

        pagination.setPageFactory(pageIndex -> {
            loadPage(pageIndex);
            return new VBox();
        });

        pagination.setCurrentPageIndex(0);
    }

    public void refresh() {
        int current = pagination.getCurrentPageIndex();

        updatePageCount();

        if (current >= pagination.getPageCount()) {
            current = pagination.getPageCount() - 1;
        }

        pagination.setCurrentPageIndex(current);
        loadPage(current);
    }

    public void loadPage(int pageIndex) {
        int from = pageIndex * rowsPerPage;
        int to = Math.min(from + rowsPerPage, fullList.size());

        if (from >= fullList.size()) {
            tableView.setItems(FXCollections.observableArrayList());
        } else {
            tableView.setItems(FXCollections.observableArrayList(fullList.subList(from, to)));
        }
    }

    public void setupDynamicRowCount() {
        tableView.heightProperty().addListener((obs, oldHeight, newHeight) -> {
            if (tableView.getFixedCellSize() > 0 && !fullList.isEmpty()) {
                int headerHeight = 40;

                int newRowsPerPage = (int)
                        ((newHeight.doubleValue() - headerHeight)
                                / tableView.getFixedCellSize());

                newRowsPerPage = Math.max(newRowsPerPage, 1);

                if (newRowsPerPage != rowsPerPage) {
                    pendingRowsPerPage = newRowsPerPage;
                    schedulePaginationUpdate();
                }
            }
        });
    }

    private void schedulePaginationUpdate() {
        if (resizeDebouncer != null) {
            resizeDebouncer.stop();
        }

        resizeDebouncer = new Timeline(new KeyFrame(Duration.millis(200), event -> {
            if (pendingRowsPerPage != rowsPerPage && !fullList.isEmpty()) {
                rowsPerPage = pendingRowsPerPage;
                refresh();
            }
        }));

        resizeDebouncer.play();
    }

    private void updatePageCount() {
        int pageCount = (int) Math.ceil((double) fullList.size() / rowsPerPage);
        pagination.setPageCount(Math.max(1, pageCount));
    }

    public int getCurrentPageIndex() {
        return pagination.getCurrentPageIndex();
    }
}
