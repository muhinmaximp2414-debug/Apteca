package com.example.apteca.model;

public interface DbNamedEnum {
    String getDbName();
}
