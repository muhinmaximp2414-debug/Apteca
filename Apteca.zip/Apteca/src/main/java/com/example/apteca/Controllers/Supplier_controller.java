package com.example.apteca.Controllers;

import com.example.apteca.Model.Supplier;
import com.example.apteca.db.DatabaseConnection;
import com.example.apteca.helpers.SortingHelper;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Duration;


import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Supplier_controller {

    public Pagination pagination;
    private Connection connection;
    private int rows_per_page = 12;

    private SortingHelper<Supplier> sortHelper;

    private Timeline resizeDebouncer;
    private int pendingRowsPerPage;

    public TableView <Supplier> supplierTable;
    public TableColumn <Supplier,String> supplierNameCollumn;
    public TableColumn <Supplier,String> supplierPhoneColumn;
    public TableColumn <Supplier,String> supplierEmailColumn;
    public TableColumn <Supplier,String> supplierAdressColumn;

    private SortedList<Supplier> sortedSupplierList;

    private final ObservableList<Supplier> supplierList = FXCollections.observableArrayList();

    public void initialize (){

        supplierNameCollumn.setCellValueFactory(new PropertyValueFactory<>("SupplierName"));
        supplierPhoneColumn.setCellValueFactory(new PropertyValueFactory<>("SupplierPhone"));
        supplierEmailColumn.setCellValueFactory(new PropertyValueFactory<>("SupplierEmail"));
        supplierAdressColumn.setCellValueFactory(new PropertyValueFactory<>("SupplierAddress"));

        supplierTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        supplierTable.setFixedCellSize(25);


        try {
            this.connection = DatabaseConnection.getConnection();

            loadDataFromDatabase();
            setupTableSorting();
            setupPagination();
            setupDinamicRowCount();
        } catch (SQLException e) {
            showError("Ошибка подключения: " + e.getMessage());
        }
    }

    private void loadDataFromDatabase() {
        String query = "SELECT ID_Supplier, Supplier_name, Supplier_phone, Supplier_email, Supplier_address FROM Supplier";

        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            supplierList.clear();

            while (resultSet.next()) {
                supplierList.add(new Supplier(
                        resultSet.getInt("id_supplier"),
                        resultSet.getString("Supplier_name"),
                        resultSet.getString("Supplier_phone"),
                        resultSet.getString("Supplier_email"),
                        resultSet.getString("Supplier_address")
                        ));
            }
            for (int i = 1; i <= 25; i++) {
                supplierList.add(new Supplier());
            }
            originalSupplierList.setAll(supplierList);

        } catch (SQLException e) {
            showError("Ошибка загрузки базы данных");
        } catch (Exception e) {
            showError(e.getMessage());
        }
    }

    public void setupPagination() {
        int pageCount = (int) Math.ceil((double) supplierList.size() / rows_per_page);

        pagination.setPageCount(Math.max(1, pageCount));

        pagination.setPageFactory(pageIndex -> {
            loadPage(pageIndex);
            return new VBox();
        });



        pagination.setCurrentPageIndex(0);
    }

    private void loadPage(int pageIndex) {
        int from = pageIndex * rows_per_page;
        int to = Math.min(from + rows_per_page, supplierList.size());
        if (from >= supplierList.size()) {
            supplierTable.setItems(FXCollections.observableArrayList());
        } else {
            supplierTable.setItems(FXCollections.observableArrayList(supplierList.subList(from, to)));
        }
    }

    private void refreshPagination() {
        int current = pagination.getCurrentPageIndex();

        int pageCount = (int) Math.ceil((double) supplierList.size() / rows_per_page);
        pageCount = Math.max(1, pageCount);

        if (current >= pageCount) {
            current = pageCount - 1;
        }
        pagination.setPageCount(pageCount);
        pagination.setCurrentPageIndex(current);

        loadPage(current);
    }

    private void setupDinamicRowCount() {
        supplierTable.heightProperty().addListener((obs, oldHeight, newHeight) -> {
            if (supplierTable.getFixedCellSize() > 0 && !supplierList.isEmpty()) {
                int headerHeight = 40;

                int newRowsPerPage = (int)
                        ((newHeight.doubleValue() - headerHeight)
                                / supplierTable.getFixedCellSize());

                newRowsPerPage = Math.max(newRowsPerPage, 1);
                if (newRowsPerPage != rows_per_page) {
                    pendingRowsPerPage = newRowsPerPage;
                    schedulePaginationUpdate();
                }
            }
        });
    }

    private void schedulePaginationUpdate() {
        if (resizeDebouncer != null) resizeDebouncer.stop();
        resizeDebouncer = new Timeline(new KeyFrame(Duration.millis(200), event -> {
            if (pendingRowsPerPage != rows_per_page && !supplierList.isEmpty()) {
                rows_per_page = pendingRowsPerPage;
                refreshPagination();
            }
        }));
        resizeDebouncer.play();
    }





    private void showError (String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText("Error");
        alert.setContentText(message);
        alert.showAndWait();
    }

    public void onSupplierAddButtonClick(ActionEvent actionEvent) {
        openEditor(null);
    }

    public void onSupplierEditButtonClick(ActionEvent actionEvent) {
        Supplier selectedSupplier = supplierTable.getSelectionModel().getSelectedItem();

        if (selectedSupplier == null) {
            showError("Выберите поставщика!");
            return;
        }

        openEditor(selectedSupplier);
    }

    public void onSupplierDeleteButtonClick(ActionEvent actionEvent) {

    }

    public void openEditor(Supplier supplier) {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/com/example/apteca/views/supplier-add-view.fxml")
            );

            Parent root = loader.load();

            SupplierAddController controller = loader.getController();
            controller.setSupplier(supplier);
            controller.setAll(supplierList);
            Scene scene = new Scene(root);
            scene.getStylesheets().add(getClass().getResource("/com/example/apteca/styles/addStyle.css").toExternalForm());

            Stage stage = new Stage();
            stage.resizableProperty().setValue(Boolean.FALSE);
            stage.setTitle(supplier == null ? "Добавить поставщика" : "Изменить поставщика");
            stage.setScene(scene);

            // делает окно модальным (блокирует основное)
            stage.initModality(Modality.APPLICATION_MODAL);

            stage.showAndWait();

            loadDataFromDatabase();
            refreshPagination();
            supplierTable.refresh();


        } catch (IOException e) {
            showError("Ошибка открытия окна: " + e.getMessage());
        }
    }

    private void setupTableSorting() {
        sortHelper = new SortingHelper<>(
                supplierTable,
                supplierList,
                originalSupplierList,
                () -> loadPage(pagination.getCurrentPageIndex())
        );

        sortHelper.addSortableColumn(supplierNameCollumn, "Название");
        sortHelper.addSortableColumn(supplierPhoneColumn, "Телефон");
        sortHelper.addSortableColumn(supplierEmailColumn, "Email");
        sortHelper.addSortableColumn(supplierAdressColumn, "Адрес");
    }
}
