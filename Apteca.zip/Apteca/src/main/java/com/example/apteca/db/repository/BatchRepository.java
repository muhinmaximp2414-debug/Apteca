package com.example.apteca.db.repository;

import com.example.apteca.model.MedicineBatch;

import com.example.apteca.db.DatabaseConnection;
import com.example.apteca.model.Medicine;
import com.example.apteca.model.Supplier;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
public class BatchRepository implements Repository<MedicineBatch> {

    @Override
    public List<MedicineBatch> findAll() throws SQLException {
        String sql = """
            SELECT
                ID_Medicine,
                Medicine_name,
                Category_name,
                Medicine_type_name,
                Active_ingredient,
                Sale_price,
                Recipe,
                ID_supplier,
                Supplier_name,
                Supplier_phone,
                Supplier_email,
                Supplier_address,
                ID_Batch,
                Purchase_price,
                Quantity,
                Expiration_date,
                Delivery_date        
            FROM Supplier_view
            """;

        List<MedicineBatch> batches = new ArrayList<>();

        try (
                Connection conn = DatabaseConnection.getConnection();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)
        ) {
            while (rs.next()) {
                Medicine medicine = new Medicine();
                medicine.setIdMedicine(rs.getInt("ID_Medicine"));
                medicine.setMedicineName(rs.getString("Medicine_name"));
                medicine.setActiveIngredient(rs.getString("Active_ingredient"));
                medicine.setSalePrice(rs.getDouble("Sale_price"));
                medicine.setRecipe(rs.getBoolean("Recipe"));

                Supplier supplier = new Supplier(
                        rs.getInt("ID_Supplier"),
                        rs.getString("Supplier_name"),
                        rs.getString("Supplier_phone"),
                        rs.getString("Supplier_email"),
                        rs.getString("Supplier_address")
                );

                MedicineBatch batch = new MedicineBatch();
                batch.setIdBatch(rs.getInt("ID_Batch"));
                batch.setMedicine(medicine);
                batch.setSupplier(supplier);
                batch.setPrice(rs.getDouble("Purchase_price"));
                batch.setQuantity(rs.getInt("Quantity"));

                Date expirationDate = rs.getDate("Expiration_date");
                if (expirationDate != null) {
                    batch.setExpirationDate(expirationDate.toLocalDate());
                }

                batch.setDeliveryDate(rs.getDate("Delivery_date").toLocalDate());

                batches.add(batch);
            }
        }

        return batches;
    }

    @Override
    public void addToDatabase(MedicineBatch batch) throws SQLException {
        String sql = "{call AddMedicineBatch(?, ?, ?, ?, ?, ?)}";

        try (
                Connection conn = DatabaseConnection.getConnection();
                CallableStatement stmt = conn.prepareCall(sql)
        ) {
            stmt.setInt(1, batch.getMedicine().getIdMedicine());
            stmt.setInt(2, batch.getSupplier().getIdsupplier());
            stmt.setDouble(3, batch.getPrice());
            stmt.setInt(4, batch.getQuantity());
            stmt.setDate(5, Date.valueOf(batch.getExpirationDate()));
            stmt.setDate(6, Date.valueOf(batch.getDeliveryDate()));

            stmt.executeUpdate();
        }
    }

    @Override
    public void updateInDatabase(MedicineBatch batch) throws SQLException {
        String sql = "{call EditMedicineBatch(?, ?, ?, ?, ?, ?, ?)}";

        try (
                Connection conn = DatabaseConnection.getConnection();
                CallableStatement stmt = conn.prepareCall(sql)
        ) {
            stmt.setInt(1, batch.getIdBatch());
            stmt.setInt(2, batch.getMedicine().getIdMedicine());
            stmt.setInt(3, batch.getSupplier().getIdsupplier());
            stmt.setDouble(4, batch.getPrice());
            stmt.setInt(5, batch.getQuantity());
            stmt.setDate(6, Date.valueOf(batch.getExpirationDate()));
            stmt.setDate(7, Date.valueOf(batch.getDeliveryDate()));

            stmt.executeUpdate();
        }
    }

    @Override
    public void deleteFromDatabase(MedicineBatch batch) throws SQLException {
        String sql = "{call DeleteMedicineBatch(?)}";

        try (
                Connection conn = DatabaseConnection.getConnection();
                CallableStatement stmt = conn.prepareCall(sql)
        ) {
            stmt.setInt(1, batch.getIdBatch());
            stmt.executeUpdate();
        }
    }
}
