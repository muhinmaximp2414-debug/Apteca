package com.example.apteca.services;

import javafx.collections.ObservableList;

import java.util.function.Predicate;

public class FilterService<T> {
    private final ObservableList<T> sourceList;
    private final ObservableList<T> filteredList;
    private final Predicate<T> filterPredicate;
    private final Runnable onFilterChanged;

    public FilterService(
            ObservableList<T> sourceList,
            ObservableList<T> filteredList,
            Predicate<T> filterPredicate,
            Runnable onFilterChanged
    ) {
        this.sourceList = sourceList;
        this.filteredList = filteredList;
        this.filterPredicate = filterPredicate;
        this.onFilterChanged = onFilterChanged;
    }

    public void applyFilter() {
        filteredList.setAll(
                sourceList.stream()
                        .filter(filterPredicate)
                        .toList()
        );

        if (onFilterChanged != null) {
            onFilterChanged.run();
        }
    }

    public void resetFilter() {
        filteredList.setAll(sourceList);

        if (onFilterChanged != null) {
            onFilterChanged.run();
        }
    }
}
