package com.example.apteca.Model;

public enum Category {
}
