package com.example.apteca.Model;

public class Medicine {
    private int id_medicine;
    private String medicine_name;
    private Supplier supplier;
    private String active_ingredient;
    private Category category;
    private double purchase_price;
    private double sales_price;
    private int quantity_in_warehouse;
    private boolean recipe;
}
