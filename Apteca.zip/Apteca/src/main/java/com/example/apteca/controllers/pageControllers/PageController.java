package com.example.apteca.controllers.pageControllers;

import com.example.apteca.controllers.changeControllers.ChangeController;
import com.example.apteca.model.DbNamedEnum;
import com.example.apteca.services.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Pagination;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public abstract class PageController<T> {
    protected final ObservableList<T> itemList = FXCollections.observableArrayList();
    protected final ObservableList<T> filteredList = FXCollections.observableArrayList();
    protected final ObservableList<T> originalList = FXCollections.observableArrayList();

    protected static final String ALL_FILTER = "Все";

    protected SortingService<T> sortHelper;
    protected PaginationService<T> paginationHelper;
    protected SearchService<T> searchHelper;
    protected final CsvExportService<T> csvExportHelper = new CsvExportService<>();

    protected abstract TableView<T> getTable();
    protected abstract Pagination getPagination();
    protected abstract TextField getSearchField();

    protected abstract List<T> findAll() throws SQLException;
    protected abstract void deleteItem(T item) throws SQLException;

    protected abstract boolean matchesSearch(T item, String searchText);
    protected abstract String getDeleteConfirmationMessage(T item);

    protected abstract void setupColumns();
    protected abstract void setupSorting();
    protected abstract void openEditor(T item);

    protected int getRowsPerPage() {
        return 12;
    }

    protected void initializeBase() {
        setupColumns();
        setupTableView();

        loadData();
        setupPagination();
        setupSorting();
        setupSearch();

        paginationHelper.refresh();
    }

    protected void loadData() {
        try {
            itemList.setAll(findAll());

            if (searchHelper != null) {
                searchHelper.applySearch();
            } else {
                filteredList.setAll(
                        itemList.stream()
                                .filter(this::matchesFilters)
                                .toList()
                );
            }

            originalList.setAll(filteredList);

        } catch (SQLException e) {
            AlertService.showError("Ошибка загрузки данных:\n" + e.getMessage());
        }
    }

    protected void setupTableView() {
        getTable().setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        getTable().setFixedCellSize(25);
    }

    protected void setupPagination() {
        paginationHelper = new PaginationService<>(
                getPagination(),
                getTable(),
                filteredList,
                getRowsPerPage()
        );

        paginationHelper.setup();
        paginationHelper.setupDynamicRowCount();
    }

    protected void setupSearch() {
        searchHelper = new SearchService<>(
                getSearchField(),
                itemList,
                filteredList,
                this::matchesSearchAndFilters,
                this::refreshFilteredTable
        );

        searchHelper.setup();
    }

    protected void refreshTableData() {
        loadData();
        refreshFilteredTable();
    }

    protected void refreshFilteredTable() {
        originalList.setAll(filteredList);

        if (sortHelper != null) {
            sortHelper.applyCurrentSort();
        }

        paginationHelper.refresh();
        getTable().refresh();
    }

    protected T getSelectedItem() {
        return getTable().getSelectionModel().getSelectedItem();
    }

    protected void handleAdd() {
        openEditor(null);
    }

    protected void handleEdit() {
        T selected = getSelectedItem();

        if (selected == null) {
            AlertService.showError("Выберите запись!");
            return;
        }

        openEditor(selected);
    }

    protected void handleDelete() {
        T selected = getSelectedItem();

        if (selected == null) {
            AlertService.showError("Выберите запись!");
            return;
        }

        if (!AlertService.showConfirmation(getDeleteConfirmationMessage(selected))) {
            return;
        }

        try {
            deleteItem(selected);
            refreshTableData();
        } catch (SQLException e) {
            AlertService.showError("Ошибка удаления:\n" + e.getMessage());
        }
    }

    protected void exportCsv(
            String title,
            String initialFileName,
            String[] headers,
            List<java.util.function.Function<T, String>> valueExtractors
    ) {
        csvExportHelper.export(
                getTable().getScene().getWindow(),
                title,
                initialFileName,
                headers,
                filteredList,
                valueExtractors
        );
    }

    protected <C extends ChangeController<T>> void openChangeEditor(
            String fxmlPath,
            String cssPath,
            String addTitle,
            String editTitle,
            T item
    ) {
        try {
            URL fxmlUrl = getClass().getResource(fxmlPath);
            URL cssUrl = getClass().getResource(cssPath);

            if (fxmlUrl == null) {
                AlertService.showError("FXML файл не найден: " + fxmlPath);
                return;
            }

            if (cssUrl == null) {
                AlertService.showError("CSS файл не найден: " + cssPath);
                return;
            }

            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            Parent root = loader.load();

            C controller = loader.getController();
            controller.setEntity(item);

            Scene scene = new Scene(root);
            scene.getStylesheets().add(cssUrl.toExternalForm());

            Stage stage = new Stage();
            stage.setResizable(false);
            stage.setTitle(item == null ? addTitle : editTitle);
            stage.setScene(scene);
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.showAndWait();

            refreshTableData();

        } catch (IOException e) {
            AlertService.showError("Ошибка открытия окна:\n" + e.getMessage());
        }
    }

    protected boolean matchesFilters(T item) {
        return true;
    }

    protected boolean matchesSearchAndFilters(T item, String searchText) {
        boolean searchMatches = searchText == null ||
                searchText.isBlank() ||
                matchesSearch(item, searchText);

        return searchMatches && matchesFilters(item);
    }

    protected void applySearchAndFilters() {
        if (searchHelper != null) {
            searchHelper.applySearch();
        } else {
            filteredList.setAll(
                    itemList.stream()
                            .filter(this::matchesFilters)
                            .toList()
            );
        }

        refreshFilteredTable();
    }

    protected void setupComboFilter(ComboBox<String> comboBox, List<String> options) {
        comboBox.getItems().setAll(options);
        comboBox.getSelectionModel().select(ALL_FILTER);
        comboBox.setOnAction(event -> applySearchAndFilters());
    }

    protected void setupCheckFilter(CheckBox checkBox) {
        checkBox.setSelected(false);
        checkBox.setOnAction(event -> applySearchAndFilters());
    }

    protected void resetComboFilter(ComboBox<String> comboBox) {
        comboBox.getSelectionModel().select(ALL_FILTER);
    }

    protected void resetCheckFilter(CheckBox checkBox) {
        checkBox.setSelected(false);
    }

    protected boolean matchesComboFilter(ComboBox<String> comboBox, String actualValue) {
        String selectedValue = comboBox.getSelectionModel().getSelectedItem();

        return selectedValue == null ||
                selectedValue.equals(ALL_FILTER) ||
                (actualValue != null && selectedValue.trim().equalsIgnoreCase(actualValue.trim()));
    }

    protected <E extends Enum<E> & DbNamedEnum> List<String> enumDbNames(Class<E> enumClass) {
        return Arrays.stream(enumClass.getEnumConstants())
                .map(DbNamedEnum::getDbName)
                .toList();
    }

    protected  <E extends Enum<E> & DbNamedEnum> List<String> enumDbNamesWithAll(Class<E> enumClass) {
        List<String> values = new ArrayList<>();
        values.add(ALL_FILTER);
        values.addAll(enumDbNames(enumClass));
        return values;
    }
}
