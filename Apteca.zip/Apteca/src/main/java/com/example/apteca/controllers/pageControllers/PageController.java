package com.example.apteca.controllers.pageControllers;

import com.example.apteca.helpers.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Pagination;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.sql.SQLException;
import java.util.List;

public abstract class PageController<T> {
    protected final ObservableList<T> itemList = FXCollections.observableArrayList();
    protected final ObservableList<T> filteredList = FXCollections.observableArrayList();
    protected final ObservableList<T> originalList = FXCollections.observableArrayList();

    protected SortingHelper<T> sortHelper;
    protected PaginationHelper<T> paginationHelper;
    protected SearchHelper<T> searchHelper;
    protected final CsvExportHelper<T> csvExportHelper = new CsvExportHelper<>();

    protected abstract TableView<T> getTable();
    protected abstract Pagination getPagination();
    protected abstract TextField getSearchField();

    protected abstract List<T> findAll() throws SQLException;
    protected abstract void deleteItem(T item) throws SQLException;

    protected abstract boolean matchesSearch(T item, String searchText);
    protected abstract String getDeleteConfirmationMessage(T item);

    protected abstract void setupColumns();
    protected abstract void setupSorting();
    protected abstract void openEditor(T item);

    protected int getRowsPerPage() {
        return 12;
    }

    protected void initializeBase() {
        setupColumns();
        setupTableView();

        loadData();
        setupPagination();
        setupSorting();
        setupSearch();

        paginationHelper.refresh();
    }

    protected void loadData() {
        try {
            itemList.setAll(findAll());

            if (searchHelper != null) {
                searchHelper.applySearch();
            } else {
                filteredList.setAll(itemList);
            }

            originalList.setAll(filteredList);

        } catch (SQLException e) {
            AlertHelper.showError("Ошибка загрузки данных:\n" + e.getMessage());
        }
    }

    protected void setupTableView() {
        getTable().setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        getTable().setFixedCellSize(25);
    }

    protected void setupPagination() {
        paginationHelper = new PaginationHelper<>(
                getPagination(),
                getTable(),
                filteredList,
                getRowsPerPage()
        );

        paginationHelper.setup();
        paginationHelper.setupDynamicRowCount();
    }

    protected void setupSearch() {
        searchHelper = new SearchHelper<>(
                getSearchField(),
                itemList,
                filteredList,
                this::matchesSearch,
                this::refreshFilteredTable
        );

        searchHelper.setup();
    }

    protected void refreshTableData() {
        loadData();
        refreshFilteredTable();
    }

    protected void refreshFilteredTable() {
        originalList.setAll(filteredList);

        if (sortHelper != null) {
            sortHelper.applyCurrentSort();
        }

        paginationHelper.refresh();
        getTable().refresh();
    }

    protected T getSelectedItem() {
        return getTable().getSelectionModel().getSelectedItem();
    }

    protected void handleAdd() {
        openEditor(null);
    }

    protected void handleEdit() {
        T selected = getSelectedItem();

        if (selected == null) {
            AlertHelper.showError("Выберите запись!");
            return;
        }

        openEditor(selected);
    }

    protected void handleDelete() {
        T selected = getSelectedItem();

        if (selected == null) {
            AlertHelper.showError("Выберите запись!");
            return;
        }

        if (!AlertHelper.showConfirmation(getDeleteConfirmationMessage(selected))) {
            return;
        }

        try {
            deleteItem(selected);
            refreshTableData();
        } catch (SQLException e) {
            AlertHelper.showError("Ошибка удаления:\n" + e.getMessage());
        }
    }
}
