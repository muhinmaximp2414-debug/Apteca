package com.example.apteca.controllers.changeControllers;

import com.example.apteca.model.Supplier;
import com.example.apteca.helpers.AlertHelper;
import com.example.apteca.repository.SupplierRepository;
import javafx.event.ActionEvent;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.sql.SQLException;

public class SupplierAddController {
    public Button btnSave;
    public TextField fieldName;
    public TextField fieldAddress;
    public TextField fieldEmail;
    public TextField fieldPhone;
    public Label changeSupplierTittle;

    private boolean editMode = false;

    private Supplier supplier;
    private final SupplierRepository supplierRepository = new SupplierRepository();



    public void initialize() {
        setupPhoneFormatter();
    }

    public void setSupplier(Supplier supplier) {
        this.supplier = supplier;
        this.editMode = supplier != null;

        updateWindowMode();

        if (editMode) {
            fillFieldsFromSupplier();
        }
    }

    public void onSaveButtonClick(ActionEvent actionEvent) {
        try {
            if (!validateForm()) {
                return;
            }

            if (!editMode) {
                supplier = new Supplier();
                fillSupplierFromFields(supplier);

                supplierRepository.addSupplierToDatabase(supplier);

            } else {
                fillSupplierFromFields(supplier);
                supplierRepository.editSupplierInDatabase(supplier);
            }

            close();

        } catch (SQLException e) {

            AlertHelper.showError("Ошибка базы данных:\n" + e.getMessage());

        } catch (Exception e) {

            AlertHelper.showError("Ошибка:\n" + e.getMessage());
        }

    }


    public void onCancelButtonClick(ActionEvent actionEvent) {
        close();
    }


    private void close() {
        ((Stage) fieldName.getScene().getWindow()).close();
    }


    private void updateWindowMode() {
        changeSupplierTittle.setText(editMode ? "Изменить поставщика" : "Добавить поставщика");
        btnSave.setText(editMode ? "Сохранить" : "Добавить");
    }


    private void fillFieldsFromSupplier() {
        fieldName.setText(supplier.getSupplierName());
        fieldAddress.setText(supplier.getSupplierAddress());
        fieldEmail.setText(supplier.getSupplierEmail());
        fieldPhone.setText(removeCountryCode(supplier.getSupplierPhone()));
    }

    private void fillSupplierFromFields(Supplier target) {
        target.setSupplierName(fieldName.getText().trim());
        target.setSupplierAddress(fieldAddress.getText().trim());
        target.setSupplierEmail(fieldEmail.getText().trim());
        target.setSupplierPhone("+373" + onlyDigits(fieldPhone.getText()));
    }


    private boolean validateForm() {
        if (isBlank(fieldName) ||
                isBlank(fieldAddress) ||
                isBlank(fieldEmail) ||
                isBlank(fieldPhone)) {
            AlertHelper.showError("Все поля должны быть заполнены!");
            return false;
        }
        return true;
    }

    private boolean isBlank(TextField field) {
        return field.getText() == null || field.getText().isBlank();
    }

    private String removeCountryCode(String phone) {
        String digits = onlyDigits(phone);

        if (digits.startsWith("373") && digits.length() > 8) {
            return digits.substring(3);
        }

        return digits;
    }

    private String onlyDigits(String value) {
        return value == null ? "" : value.replaceAll("\\D", "");
    }

    private void setupPhoneFormatter(){
        fieldPhone.setTextFormatter(new TextFormatter<String>(change -> {
            String digits = onlyDigits(change.getControlNewText());

            if (digits.length() > 8) {
                return null;
            }

            String formatted = formatPhone(digits);

            change.setText(formatted);
            change.setRange(0, change.getControlText().length());
            change.setCaretPosition(formatted.length());
            change.setAnchor(formatted.length());

            return change;
        }));
    }

    private String formatPhone(String digits) {
        StringBuilder formatted = new StringBuilder();

        for (int i = 0; i < digits.length(); i++) {
            if (i == 2 || i == 5) {
                formatted.append(" ");
            }

            formatted.append(digits.charAt(i));
        }

        return formatted.toString();
    }

}
