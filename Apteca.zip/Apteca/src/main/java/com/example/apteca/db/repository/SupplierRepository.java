package com.example.apteca.db.repository;

import com.example.apteca.model.Supplier;
import com.example.apteca.db.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SupplierRepository implements Repository<Supplier> {
    public List<Supplier> findAll() throws SQLException {
        String sql = """
                SELECT ID_Supplier, Supplier_name, Supplier_phone, Supplier_email, Supplier_address
                FROM Supplier
                """;

        List<Supplier> suppliers = new ArrayList<>();

        try (
                Connection conn = DatabaseConnection.getConnection();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)
        ) {
            while (rs.next()) {
                suppliers.add(new Supplier(
                        rs.getInt("ID_Supplier"),
                        rs.getString("Supplier_name"),
                        rs.getString("Supplier_phone"),
                        rs.getString("Supplier_email"),
                        rs.getString("Supplier_address")
                ));
            }
        }

        return suppliers;
    }

    public void addToDatabase(Supplier supplier) throws SQLException {
        String sql = "{call AddSupplier(?, ?, ?, ?)}";

        try (
                Connection conn = DatabaseConnection.getConnection();
                CallableStatement stmt = conn.prepareCall(sql)
        ) {
            stmt.setString(1, supplier.getSupplierName());
            stmt.setString(2, supplier.getSupplierPhone());
            stmt.setString(3, supplier.getSupplierEmail());
            stmt.setString(4, supplier.getSupplierAddress());

            stmt.executeUpdate();
        }
    }

    public void updateInDatabase(Supplier supplier) throws SQLException {
        String sql = "{call EditSupplier(?, ?, ?, ?, ?)}";

        try (
                Connection conn = DatabaseConnection.getConnection();
                CallableStatement stmt = conn.prepareCall(sql)
        ) {
            stmt.setInt(1, supplier.getIdsupplier());
            stmt.setString(2, supplier.getSupplierName());
            stmt.setString(3, supplier.getSupplierPhone());
            stmt.setString(4, supplier.getSupplierEmail());
            stmt.setString(5, supplier.getSupplierAddress());

            stmt.executeUpdate();
        }
    }

    public void deleteFromDatabase(Supplier supplier) throws SQLException {
        String sql = "{call DeleteSupplier(?)}";
        try (
                Connection conn = DatabaseConnection.getConnection();
                CallableStatement stmt = conn.prepareCall(sql)
        ) {
            stmt.setInt(1, supplier.getIdsupplier());
            stmt.executeUpdate();
        }
    }
}
